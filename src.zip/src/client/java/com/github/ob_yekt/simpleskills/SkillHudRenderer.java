
package com.github.ob_yekt.simpleskills;

import com.github.ob_yekt.simpleskills.managers.DatabaseManager;
import com.github.ob_yekt.simpleskills.managers.XPManager;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.UUID;

public class SkillHudRenderer implements HudElement {
    private static final Identifier HUD_ID = Identifier.fromNamespaceAndPath("simpleskills", "skill_hud");
    private static final Map<UUID, Boolean> playerHudVisibility = new HashMap<>();
    private static final int PADDING = 3;
    private static final int LINE_HEIGHT = 8;
    private static final int BAR_WIDTH = 40;
    private static final int BAR_HEIGHT = 4;
    private static final int ELEMENT_SPACING = 5;

    // Colors
    private static final int TEXT_COLOR = 0xFFFFFFFF; // White
    private static final int HEADER_COLOR = 0xFFFF4444; // Red
    private static final int LEVEL_COLOR = 0xFF55FFFF; // Cyan
    private static final int XP_COLOR = 0xFF88FF88; // Light green
    private static final int PROGRESS_FILLED_COLOR = 0xFF55FF55; // Green
    private static final int PROGRESS_EMPTY_COLOR = 0xFF555555; // Gray

    // Cache for performance
    private static UUID cachedPlayerUuid = null;
    private static HudSize cachedSize = null;
    private static long lastSkillUpdateTime = 0;

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, DeltaTracker deltaTracker) {
        if (!shouldRenderHud()) return;

        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        UUID playerUuid = client.player.getUUID();
        HudSize size = calculateHudSize(playerUuid);
        int[] pos = getHudPosition(size.width, size.height);

        try {
            renderSkillPanel(context, pos[0], pos[1], size.width, size.height, playerUuid);
        } catch (Exception e) {
            Simpleskills.LOGGER.error("Failed to render skill HUD: {}", e.getMessage());
        }
    }

    private static class HudSize {
        int width;
        int height;

        HudSize(int width, int height) {
            this.width = width;
            this.height = height;
        }
    }

    public static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.BOSS_BAR, HUD_ID, new SkillHudRenderer());
    }

    public static void toggleHudVisibility() {
        // Skip in multiplayer
        if (SimpleskillsClient.isMultiplayer()) {
            Simpleskills.LOGGER.info("[simpleskills] HUD toggle ignored in multiplayer.");
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        UUID playerUuid = client.player.getUUID();
        boolean isVisible = playerHudVisibility.getOrDefault(playerUuid, true);

        playerHudVisibility.put(playerUuid, !isVisible);

        // Clear cache when visibility changes
        cachedPlayerUuid = null;
        cachedSize = null;

        if (!isVisible) {
            client.player.sendSystemMessage(Component.literal("§6[simpleskills]§f Skill HUD enabled."));
        } else {
            client.player.sendSystemMessage(Component.literal("§6[simpleskills]§f Skill HUD disabled."));
        }
    }

    private boolean shouldRenderHud() {
        // Disable HUD entirely in multiplayer
        if (SimpleskillsClient.isMultiplayer()) {
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return false;

        UUID playerUuid = client.player.getUUID();
        return playerHudVisibility.getOrDefault(playerUuid, true);
    }

    private HudSize calculateHudSize(UUID playerUuid) {
        // Use cache if available and player hasn't changed
        if (cachedPlayerUuid != null && cachedPlayerUuid.equals(playerUuid) && cachedSize != null) {
            if (System.currentTimeMillis() - lastSkillUpdateTime < 5000) {
                return cachedSize;
            }
        }

        DatabaseManager db = DatabaseManager.getInstance();
        if (db == null) return new HudSize(200, 100); // Fallback size

        String playerUuidStr = playerUuid.toString();
        Font font = Minecraft.getInstance().font;

        // Ensure player is initialized
        if (db.getAllSkills(playerUuidStr).isEmpty()) {
            db.initializePlayer(playerUuidStr);
        }

        boolean isIronman = db.isPlayerInIronmanMode(playerUuidStr);
        int prestige = db.getPrestige(playerUuidStr);
        Map<String, DatabaseManager.SkillData> skills = db.getAllSkills(playerUuidStr);

        int maxWidth = 0;
        int height = PADDING;

        // Header
        String headerText = "⚔ Skills ⚔";
        maxWidth = Math.max(maxWidth, font.width(headerText));
        height += LINE_HEIGHT + 2;

        // Ironman mode indicator
        if (isIronman) {
            String ironmanText = "Ironman Mode";
            maxWidth = Math.max(maxWidth, font.width(ironmanText));
            height += LINE_HEIGHT + 1;
        }

        // Prestige indicator
        if (prestige > 0) {
            String prestigeText = String.format("Prestige: ★%d", prestige);
            maxWidth = Math.max(maxWidth, font.width(prestigeText));
            height += LINE_HEIGHT + 1;
        }

        // Separator
        height += 3;

        // Skills
        for (Skills skillEnum : Skills.values()) {
            String skillName = skillEnum.getId();
            DatabaseManager.SkillData skill = skills.getOrDefault(skillName, new DatabaseManager.SkillData(0, 1));
            Component skillDisplayName = getSkillDisplayName(skillEnum);
            int lineWidth;

            if (skill.level() == XPManager.getMaxLevel()) {
                Component skillText = Component.literal("⭐ ")
                        .append(skillDisplayName)
                        .append(Component.literal(String.format(" Lvl 99 [XP: %,d]", skill.xp())));
                lineWidth = font.width(skillText);
            } else {
                int xpForCurrentLevel = XPManager.getExperienceForLevel(skill.level());
                int xpToNextLevel = XPManager.getExperienceForLevel(skill.level() + 1) - xpForCurrentLevel;
                int progressToNextLevel = skill.xp() - xpForCurrentLevel;
                Component skillText = Component.empty()
                        .append(skillDisplayName)
                        .append(Component.literal(String.format(" Lvl %d [%,d/%,d]",
                                skill.level(), progressToNextLevel, xpToNextLevel)));
                lineWidth = font.width(skillText) + ELEMENT_SPACING + BAR_WIDTH;
            }

            maxWidth = Math.max(maxWidth, lineWidth);
            height += LINE_HEIGHT + 1;
        }

        // Total level
        int totalLevels = skills.values().stream().mapToInt(DatabaseManager.SkillData::level).sum();
        String totalText = String.format("Total: %d", totalLevels);
        maxWidth = Math.max(maxWidth, font.width(totalText));
        height += 2 + 3 + LINE_HEIGHT;

        // Bottom padding
        height += PADDING;

        // Add side paddings to width
        int panelWidth = maxWidth + 2 * (PADDING + 5);

        // Cache the result
        cachedSize = new HudSize(panelWidth, height);
        cachedPlayerUuid = playerUuid;
        lastSkillUpdateTime = System.currentTimeMillis();

        return cachedSize;
    }

    private int[] getHudPosition(int panelWidth, int panelHeight) {
        Minecraft client = Minecraft.getInstance();
        int windowWidth = client.getWindow().getGuiScaledWidth();
        int windowHeight = client.getWindow().getGuiScaledHeight();
        int margin = 10;
        ClientConfig.HudPosition position = ClientConfig.getHudPosition();
        int x, y;

        switch (position) {
            case TOP_LEFT:
                x = margin;
                y = margin;
                break;
            case TOP_CENTER:
                x = (windowWidth - panelWidth) / 2;
                y = margin;
                break;
            case TOP_RIGHT:
                x = windowWidth - panelWidth - margin;
                y = margin;
                break;
            case MIDDLE_LEFT:
                x = margin;
                y = (windowHeight - panelHeight) / 2;
                break;
            case MIDDLE_CENTER:
                x = (windowWidth - panelWidth) / 2;
                y = (windowHeight - panelHeight) / 2;
                break;
            case MIDDLE_RIGHT:
                x = windowWidth - panelWidth - margin;
                y = (windowHeight - panelHeight) / 2;
                break;
            case BOTTOM_LEFT:
                x = margin;
                y = windowHeight - panelHeight - margin;
                break;
            case BOTTOM_CENTER:
                x = (windowWidth - panelWidth) / 2;
                y = windowHeight - panelHeight - margin;
                break;
            case BOTTOM_RIGHT:
                x = windowWidth - panelWidth - margin;
                y = windowHeight - panelHeight - margin;
                break;
            default:
                x = margin;
                y = margin;
                break;
        }

        return new int[]{x, y};
    }

    private void renderSkillPanel(GuiGraphicsExtractor context, int x, int y, int panelWidth, int panelHeight, UUID playerUuid) {
        DatabaseManager db = DatabaseManager.getInstance();
        if (db == null) return;

        String playerUuidStr = playerUuid.toString();
        Font font = Minecraft.getInstance().font;

        int currentY = y + PADDING;

        String headerText = "⚔ Skills ⚔";
        context.text(font, headerText, x + PADDING, currentY, HEADER_COLOR, false);
        currentY += LINE_HEIGHT + 2;

        boolean isIronman = db.isPlayerInIronmanMode(playerUuidStr);
        int prestige = db.getPrestige(playerUuidStr);
        if (isIronman) {
            String ironmanText = "Ironman Mode";
            context.text(font, ironmanText, x + PADDING, currentY, 0xFFFF4444, false);
            currentY += LINE_HEIGHT + 1;
        }

        if (prestige > 0) {
            String prestigeText = String.format("Prestige: ★%d", prestige);
            context.text(font, prestigeText, x + PADDING, currentY, 0xFFFFD700, false);
            currentY += LINE_HEIGHT + 1;
        }

        context.horizontalLine(x + PADDING, x + panelWidth - PADDING, currentY, 0xFF666666);
        currentY += 3;

        Map<String, DatabaseManager.SkillData> skills = db.getAllSkills(playerUuidStr);

        for (Skills skillEnum : Skills.values()) {
            String skillName = skillEnum.getId();
            DatabaseManager.SkillData skill = skills.getOrDefault(skillName, new DatabaseManager.SkillData(0, 1));

            currentY = renderSkillLine(context, x + PADDING, currentY, skill, getSkillDisplayName(skillEnum));
            currentY += 1;
        }

        currentY += 2;
        context.horizontalLine(x + PADDING, x + panelWidth - PADDING, currentY, 0xFF666666);
        currentY += 3;

        int totalLevels = skills.values().stream().mapToInt(DatabaseManager.SkillData::level).sum();
        String totalText = String.format("Total: %d", totalLevels);
        context.text(font, totalText, x + PADDING, currentY, LEVEL_COLOR, false);
    }

    private int renderSkillLine(GuiGraphicsExtractor context, int x, int y,
                                DatabaseManager.SkillData skill, Component skillDisplayName) {
        Font font = Minecraft.getInstance().font;

        if (skill.level() == XPManager.getMaxLevel()) {
            Component skillText = Component.literal("⭐ ")
                    .append(skillDisplayName)
                    .append(Component.literal(String.format(" Lvl 99 [XP: %,d]", skill.xp())));
            context.text(font, skillText, x, y, 0xFFFFD700, false);
        } else {
            int xpForCurrentLevel = XPManager.getExperienceForLevel(skill.level());
            int xpToNextLevel = XPManager.getExperienceForLevel(skill.level() + 1) - xpForCurrentLevel;
            int progressToNextLevel = skill.xp() - xpForCurrentLevel;

            Component skillText = Component.empty()
                    .append(skillDisplayName)
                    .append(Component.literal(String.format(" Lvl %d", skill.level())));
            context.text(font, skillText, x, y, TEXT_COLOR, false);

            int barX = x + font.width(skillText) + ELEMENT_SPACING;
            int barY = y + (LINE_HEIGHT - BAR_HEIGHT) / 2;
            renderProgressBar(context, barX, barY, BAR_WIDTH, BAR_HEIGHT, progressToNextLevel, xpToNextLevel);

            String xpText = String.format("[%,d/%,d]", progressToNextLevel, xpToNextLevel);
            int xpTextX = barX + BAR_WIDTH + ELEMENT_SPACING;
            context.text(font, xpText, xpTextX, y, XP_COLOR, false);
        }

        return y + LINE_HEIGHT;
    }

    private static Component getSkillDisplayName(Skills skill) {
        String translationKey = "skill.simpleskills.name." + skill.name().toLowerCase(Locale.ROOT);
        return Component.translatable(translationKey);
    }

    private void renderProgressBar(GuiGraphicsExtractor context, int x, int y, int width, int height, int progress, int total) {
        if (total <= 0) total = 1;
        progress = Math.max(0, Math.min(progress, total));

        context.fill(x, y, x + width, y + height, PROGRESS_EMPTY_COLOR);

        int filledWidth = (int) ((double) progress / total * width);
        if (filledWidth > 0) {
            context.fill(x, y, x + filledWidth, y + height, PROGRESS_FILLED_COLOR);
        }

        context.horizontalLine(x, x + width - 1, y, 0xFF888888);
        context.horizontalLine(x, x + width - 1, y + height - 1, 0xFF888888);
        context.verticalLine(x, y, y + height - 1, 0xFF888888);
        context.verticalLine(x + width - 1, y, y + height - 1, 0xFF888888);
    }

    public static void clearPlayerVisibility(UUID playerUuid) {
        playerHudVisibility.remove(playerUuid);
        if (playerUuid.equals(cachedPlayerUuid)) {
            cachedPlayerUuid = null;
            cachedSize = null;
        }
        Simpleskills.LOGGER.debug("Cleared HUD visibility for player UUID: {}", playerUuid);
    }

    public static void refreshCache() {
        cachedPlayerUuid = null;
        cachedSize = null;
    }
}
