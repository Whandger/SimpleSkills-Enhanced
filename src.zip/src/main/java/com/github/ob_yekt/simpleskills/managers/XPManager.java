package com.github.ob_yekt.simpleskills.managers;

import com.github.ob_yekt.simpleskills.Simpleskills;
import com.github.ob_yekt.simpleskills.agility.AgilityManager;
import com.github.ob_yekt.simpleskills.DefenseCombat;
import com.github.ob_yekt.simpleskills.VeinMining;
import com.github.ob_yekt.simpleskills.excavating.ExcavatingManager;
import com.github.ob_yekt.simpleskills.farming.FarmingPerks;
import com.github.ob_yekt.simpleskills.shields.CraftingLevelLock;
import com.github.ob_yekt.simpleskills.TreeFeller;
import com.github.ob_yekt.simpleskills.Skills;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.IntUnaryOperator;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

public class XPManager {
    private static final int MAX_LEVEL = 99;
    private static BiConsumer<ServerPlayer, Skills> onXPChangeListener;

    private static double STANDARD_XP_MULTIPLIER;
    private static double IRONMAN_XP_MULTIPLIER;
    private static boolean XP_NOTIFICATIONS_ENABLED;
    private static int XP_NOTIFICATION_THRESHOLD;
    private static boolean LEVEL_UP_EFFECTS_ENABLED;
    private static boolean LEVEL_UP_NOTIFICATIONS_ENABLED;

    static {
        loadConfig();
    }

    // Provide access to MAX_LEVEL
    public static int getMaxLevel() {
        return MAX_LEVEL;
    }

    // Set an optional listener for XP and level changes
    public static void setOnXPChangeListener(BiConsumer<ServerPlayer, Skills> listener) {
        onXPChangeListener = listener;
    }

    // Get a player's skill level
    public static int getSkillLevel(String playerUuid, Skills skill) {
        if (playerUuid == null || skill == null) {
            Simpleskills.LOGGER.error("Invalid input for getSkillLevel: playerUuid or skill is null");
            return 1;
        }
        DatabaseManager db = DatabaseManager.getInstance();
        Map<String, DatabaseManager.SkillData> skills = db.getAllSkills(playerUuid);
        DatabaseManager.SkillData skillData = skills.get(skill.getId());
        if (skillData != null) {
            return skillData.level();
        }
        // Return default level without forcing initialization
        return 1;
    }

    /// IMPROVED XP-SYSTEM

// Curve parameters tuned for ~45 min to level 25 (wood+stone) and exactly 20.4 hours to level 99
    private static final double SCALING_A  = 50.751;
    private static final double EXPONENT_P = 2.672;
    private static final double OFFSET_K   = 0.295;

    public static int getExperienceForLevel(int level) {
        if (level <= 1) return 0;
        double base = Math.pow(1.0 + OFFSET_K, EXPONENT_P);
        return (int) Math.floor(SCALING_A * (Math.pow((double) level + OFFSET_K, EXPONENT_P) - base));
    }

    public static int getLevelForExperience(int experience) {
        return calculateLevelForExperience(experience, XPManager::getExperienceForLevel);
    }

    /// OLD XP-SYSTEM (for migration purposes only)

    // Old curve parameters
    private static final double OLD_EXPONENT_P = 2.45;
    private static final double OLD_SCALING_A  = 300.0;
    private static final double OLD_FLOOR_B    = 500.0;

    /**
     * Old XP calculation function - used only for migration.
     * Calculates the experience required for a given level in the old system.
     */
    public static int getExperienceForLevelOld(int level) {
        if (level <= 1) return 0;
        double L = level - 1;
        return (int) Math.floor(OLD_SCALING_A * Math.pow(L, OLD_EXPONENT_P) + OLD_FLOOR_B * L);
    }

    /**
     * Old level calculation function - used only for migration.
     * Calculates the level for a given experience amount in the old system.
     */
    public static int getLevelForExperienceOld(int experience) {
        return calculateLevelForExperience(experience, XPManager::getExperienceForLevelOld);
    }

    /**
     * Generic binary search helper to calculate level from experience.
     * Uses the provided XP calculation function to determine the level.
     */
    private static int calculateLevelForExperience(int experience, IntUnaryOperator xpCalculator) {
        if (experience <= 0) return 1;
        int low = 1;
        int high = MAX_LEVEL;
        while (low < high) {
            int mid = (low + high + 1) >>> 1; // bias upward
            int xpForMid = xpCalculator.applyAsInt(mid);
            if (xpForMid <= experience) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return low;
    }

    // Add XP to a player's skill silently (no notifications or level-up effects)
    public static void addXPSilent(ServerPlayer player, Skills skill, int xpToAdd) {
        updatePlayerSkill(player, skill, xpToAdd, false, false);
    }

    // Add XP to a player's skill with notifications
    public static void addXPWithNotification(ServerPlayer player, Skills skill, int xpToAdd) {
        updatePlayerSkill(player, skill, xpToAdd, true, true);
    }

    // Shared logic for updating player skill
    private static void updatePlayerSkill(ServerPlayer player, Skills skill, int xpToAdd, boolean notifyXP, boolean notifyLevelUp) {
        if (player == null || skill == null) {
            Simpleskills.LOGGER.error("Invalid input: player or skill is null");
            return;
        }
        if (xpToAdd <= 0) {
            Simpleskills.LOGGER.warn("Invalid xpToAdd: {} for player UUID: {}, skill: {}", xpToAdd, player.getStringUUID(), skill.getId());
            return;
        }

        String playerUuid = player.getStringUUID();
        DatabaseManager db = DatabaseManager.getInstance();

        // Apply multiplier with fallback
        double multiplier = db.isPlayerInIronmanMode(playerUuid) ? IRONMAN_XP_MULTIPLIER : STANDARD_XP_MULTIPLIER;
        xpToAdd = (int) (xpToAdd * multiplier);

        // Ensure player is initialized (checks first, avoids redundant DB ops)
        db.ensurePlayerInitialized(playerUuid);
        Map<String, DatabaseManager.SkillData> skills = db.getAllSkills(playerUuid);
        DatabaseManager.SkillData skillData = skills.getOrDefault(skill.getId(), new DatabaseManager.SkillData(0, 0));
        int currentXP = skillData.xp();
        int currentLevel = skillData.level();
        int newXP = currentXP + xpToAdd;
        int newLevel = getLevelForExperience(newXP);

        // Save to database
        try {
            db.savePlayerSkill(playerUuid, skill.getId(), newXP, newLevel);
        } catch (Exception e) {
            Simpleskills.LOGGER.error("Failed to save player skill data for UUID: {}, skill: {}", playerUuid, skill.getId(), e);
            return;
        }

        // Notify every Vein Mining tier crossed by this Mining level-up.
        if (skill == Skills.MINING && newLevel > currentLevel) {
            VeinMining.notifyUnlockedMilestones(player, currentLevel, newLevel);
        }

        if (skill == Skills.WOODCUTTING && newLevel > currentLevel) {
            TreeFeller.notifyUnlocked(player, currentLevel, newLevel);
        }

        // Farming 5: teach Bone Meal Mastery and Auto Plant (only these two perks have unlock messages).
        if (skill == Skills.FARMING && newLevel > currentLevel) {
            FarmingPerks.notifyUnlocked(player, currentLevel, newLevel);
        }

        // Crafting 15: teach how to craft the Glowstone Shield and its upgrades.
        if (skill == Skills.CRAFTING && newLevel > currentLevel) {
            CraftingLevelLock.notifyUnlocked(player, currentLevel, newLevel);
        }

        // Tell the player when an Excavating level-up reaches a new rank.
        if (skill == Skills.EXCAVATING && newLevel > currentLevel) {
            ExcavatingManager.notifyRankUp(player, currentLevel, newLevel);
        }

        if (skill == Skills.DEFENSE && newLevel > currentLevel) {
            notifyDefenseUnlocks(player, currentLevel, newLevel);
        }

        if (skill == Skills.AGILITY && newLevel > currentLevel) {
            AgilityManager.notifyUnlocks(player, currentLevel, newLevel);
        }

        // Send XP gain notification if enabled
        if (notifyXP) {
            if (XP_NOTIFICATIONS_ENABLED && xpToAdd >= XP_NOTIFICATION_THRESHOLD) {
                player.sendSystemMessage(Component.literal(String.format("Gained %d XP in %s!", xpToAdd, skill.getDisplayName()))
                        .withStyle(ChatFormatting.GOLD), true);
            }
        }

        // Handle level-up if enabled
        if (notifyLevelUp && newLevel > currentLevel) {
            triggerLevelUpEffects(player, skill, newLevel);
        }

        // Update attributes and UI
        AttributeManager.updatePlayerAttributes(player, skill, new DatabaseManager.SkillData(newXP, newLevel));

        // Notify listener
        if (onXPChangeListener != null) {
            onXPChangeListener.accept(player, skill);
        }
    }

    public static void notifyDefenseUnlocks(ServerPlayer player, int oldLevel, int newLevel) {
        if (newLevel <= oldLevel) return;
        int[] parryTierLevels = {20, 40, 60, 70, 80, 90};
        for (int tierLevel : parryTierLevels) {
            if (oldLevel < tierLevel && newLevel >= tierLevel) {
                player.sendSystemMessage(Component.translatable("message.simpleskills.defense.parry_tier_up",
                        Component.translatable("skill.simpleskills.defense.parry_tier_" + tierLevel),
                        DefenseCombat.getParryWindowTicks(tierLevel)).withStyle(ChatFormatting.GOLD));
            }
        }
        int[] levels = {10, 30, 50, 75, 99};
        String[] keys = {
                "message.simpleskills.defense.perfect_parry_unlocked",
                "message.simpleskills.defense.projectile_reflection_unlocked",
                "message.simpleskills.defense.enhanced_parry_unlocked",
                "message.simpleskills.defense.counter_mastery_unlocked",
                "message.simpleskills.defense.master_defender_unlocked"
        };
        for (int i = 0; i < levels.length; i++) {
            if (oldLevel < levels[i] && newLevel >= levels[i]) {
                player.sendSystemMessage(Component.translatable(keys[i]).withStyle(ChatFormatting.GOLD));
            }
        }
    }

    // Handle level-up effects
    private static void triggerLevelUpEffects(ServerPlayer player, Skills skill, int newLevel) {
        ServerLevel serverWorld = player.level();
        String levelUpMessage;
        boolean isMaxLevel = newLevel == MAX_LEVEL;
        if (isMaxLevel) {
            levelUpMessage = String.format("Congratulations! You have reached max level in %s!", skill.getDisplayName());
            if (LEVEL_UP_NOTIFICATIONS_ENABLED) {
                player.sendSystemMessage(Component.literal(levelUpMessage).withStyle(ChatFormatting.GOLD), false);
            }
            if (LEVEL_UP_EFFECTS_ENABLED) {
                serverWorld.playSound(null, player.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE,
                        SoundSource.PLAYERS, 0.9f, 1.2f);
            }
        } else {
            levelUpMessage = String.format("You leveled up in %s! New level: %d", skill.getDisplayName(), newLevel);
            if (LEVEL_UP_NOTIFICATIONS_ENABLED) {
                player.sendSystemMessage(Component.literal(levelUpMessage).withStyle(ChatFormatting.GOLD), false);
            }
            if (LEVEL_UP_EFFECTS_ENABLED) {
                serverWorld.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                        SoundSource.PLAYERS, 0.7f, 1.3f);
            }
        }
        if (LEVEL_UP_EFFECTS_ENABLED) {
            spawnConfettiParticles(serverWorld, player.getX(), player.getY(), player.getZ(), isMaxLevel);
        }
    }

    // Spawn confetti particles with hardcoded values
    private static void spawnConfettiParticles(ServerLevel serverWorld, double x, double y, double z, boolean isMaxLevel) {
        ParticleOptions[] particles = new ParticleOptions[]{
                ParticleTypes.HAPPY_VILLAGER,
                ParticleTypes.ENCHANTED_HIT,
                ParticleTypes.FIREWORK,
                ParticleTypes.CRIT
        };
        int count = isMaxLevel ? 200 : 75;
        double spread = isMaxLevel ? 2.0 : 1.0;

        for (ParticleOptions particle : particles) {
            serverWorld.sendParticles(
                    particle,
                    x, y + 1.5, z,
                    count / particles.length,
                    spread, spread, spread,
                    0.05
            );
        }
        if (isMaxLevel) {
            serverWorld.sendParticles(
                    ParticleTypes.FIREWORK,
                    x, y + 1.5, z,
                    50,
                    1.5, 1.5, 1.5,
                    0.1
            );
        }
    }

    // Config helper methods

    private static void loadConfig() {
        JsonObject config = ConfigManager.getFeatureConfig();
        STANDARD_XP_MULTIPLIER = getConfigDouble(config, "standard_xp_multiplier", 1.0);
        IRONMAN_XP_MULTIPLIER = getConfigDouble(config, "ironman_xp_multiplier", 0.5);
        XP_NOTIFICATIONS_ENABLED = getConfigBoolean(config, "xp_notifications_enabled", true);
        XP_NOTIFICATION_THRESHOLD = getConfigInt(config, "xp_notification_threshold", 10);
        LEVEL_UP_EFFECTS_ENABLED = getConfigBoolean(config, "level_up_effects_enabled", true);
        LEVEL_UP_NOTIFICATIONS_ENABLED = getConfigBoolean(config, "level_up_notifications_enabled", true);
    }

    public static void reloadConfig() {
        loadConfig();
        Simpleskills.LOGGER.info("Reloaded XPManager config values.");
    }

    private static double getConfigDouble(JsonObject config, String key, double defaultValue) {
        if (config.has(key) && config.get(key).isJsonPrimitive() && config.getAsJsonPrimitive(key).isNumber()) {
            return config.get(key).getAsDouble();
        }
        Simpleskills.LOGGER.warn("Invalid or missing config key '{}', using default: {}", key, defaultValue);
        return defaultValue;
    }

    private static int getConfigInt(JsonObject config, String key, int defaultValue) {
        if (config.has(key) && config.get(key).isJsonPrimitive() && config.getAsJsonPrimitive(key).isNumber()) {
            return config.get(key).getAsInt();
        }
        Simpleskills.LOGGER.warn("Invalid or missing config key '{}', using default: {}", key, defaultValue);
        return defaultValue;
    }

    private static boolean getConfigBoolean(JsonObject config, String key, boolean defaultValue) {
        if (config.has(key) && config.get(key).isJsonPrimitive() && config.getAsJsonPrimitive(key).isBoolean()) {
            return config.get(key).getAsBoolean();
        }
        Simpleskills.LOGGER.warn("Invalid or missing config key '{}', using default: {}", key, defaultValue);
        return defaultValue;
    }
}
