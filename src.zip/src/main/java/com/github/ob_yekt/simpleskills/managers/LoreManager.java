package com.github.ob_yekt.simpleskills.managers;

import com.github.ob_yekt.simpleskills.Simpleskills;
import com.github.ob_yekt.simpleskills.requirements.SkillRequirement;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

/**
 * Manages lore application for items, including requirements for tools, armor, weapons, and prayer sacrifices.
 * Consolidated functionality from LoreApplier into a single class for simplicity.
 * Modified to be server-side only, avoiding custom components and client-side dependencies.
 */
public class LoreManager {
    private static final String LORE_PREFIX = "Requires";
    private static final String TO_USE = " to use";

    // Record to hold tier name and its color (as integer RGB)
    public record TierInfo(String name, int color) {}

    public static void initialize() {
        // No component registration needed, as we avoid custom components
    }

    /**
     * Applies skill-related lore to the given item stack.
     * Checks for tool, armor, weapon, enchantment, and prayer sacrifice requirements.
     */
    public static void applySkillLore(ItemStack stack) {
        applyLoreToStack(stack);
    }

    public static void applyLoreToStack(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        // Check if item requirements should be displayed in tooltips
        if (!isItemRequirementsInTooltipsEnabled()) {
            return;
        }

        String itemId = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        List<Component> newLore = new ArrayList<>();

        // Handle item requirements (tools, armor, weapons, sacrifices)
        SkillRequirement requirement = getItemRequirement(itemId);
        if (requirement != null) {
            String action = TO_USE;
            String skillName = requirement.getSkill().getId().substring(0, 1).toUpperCase() +
                    requirement.getSkill().getId().substring(1).toLowerCase();
            String prestigePart = requirement.getRequiredPrestige() > 0 ? String.format(
                    " and Prestige ★%d", requirement.getRequiredPrestige()) : "";
            String loreText = String.format("Requires %d %s%s%s", requirement.getLevel(), skillName, prestigePart, action);

            // Check existing lore to avoid duplicates
            ItemLore currentLoreComponent = stack.getOrDefault(DataComponents.LORE, new ItemLore(List.of()));
            boolean loreExists = currentLoreComponent.lines().stream()
                    .anyMatch(text -> text.getString().equals(loreText));
            if (loreExists) {
                return;
            }

            newLore.add(Component.literal(loreText).withStyle(ChatFormatting.GRAY));
        }

        if (!newLore.isEmpty()) {
            List<Component> currentLore = stack.getOrDefault(DataComponents.LORE, new ItemLore(List.of())).lines();
            List<Component> filteredLore = currentLore.stream()
                    .filter(text -> !text.getString().contains(LORE_PREFIX))
                    .toList();
            newLore.addAll(0, filteredLore);

            stack.set(DataComponents.LORE, new ItemLore(newLore));
            Simpleskills.LOGGER.debug("Applied lore to item: {}", itemId);
        }
    }

    /**
     * Applies lore to all stacks in the given inventory.
     */
    public static void applyLoreToInventory(Container inventory) {
        if (inventory == null) {
            return;
        }
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            applyLoreToStack(stack);
        }
    }

    /**
     * Helper method to retrieve the appropriate SkillRequirement for an item.
     * Checks tools, armor, weapons, and prayer sacrifices in order.
     */
    private static SkillRequirement getItemRequirement(String itemId) {
        SkillRequirement toolReq = ConfigManager.getToolRequirement(itemId);
        if (toolReq != null) return toolReq;

        SkillRequirement armorReq = ConfigManager.getArmorRequirement(itemId);
        if (armorReq != null) return armorReq;

        SkillRequirement weaponReq = ConfigManager.getWeaponRequirement(itemId);
        if (weaponReq != null) return weaponReq;
        return null;
    }

    /**
     * Returns the tier name and color based on the skill level.
     * @param level The skill level.
     * @return TierInfo containing the tier name and its RGB color as an integer.
     */
    public static TierInfo getTierName(int level) {
        if (level >= 99) return new TierInfo("Grandmaster", 0xFF8000); // #ff8000 (RGB: 255, 128, 0)
        else if (level >= 75) return new TierInfo("Expert", 0xA335EE); // #a335ee (RGB: 163, 53, 238)
        else if (level >= 50) return new TierInfo("Artisan", 0x0070DD); // #0070dd (RGB: 0, 112, 221)
        else if (level >= 25) return new TierInfo("Journeyman", 0x1EFF00); // #1eff00 (RGB: 30, 255, 0)
        else return new TierInfo("Novice", 0x9D9D9D); // #9d9d9d (RGB: 157, 157, 157)
    }

    /**
     * Checks if the display of item requirements in tooltips is enabled.
     * This is controlled by a config option.
     * @return True if the item requirements should be displayed, false otherwise.
     */
    private static boolean isItemRequirementsInTooltipsEnabled() {
        return ConfigManager.getFeatureConfig().get("item_requirements_in_tooltips_enabled").getAsBoolean();
    }
}
