package com.github.ob_yekt.simpleskills;

import com.github.ob_yekt.simpleskills.commands.SimpleskillsCommands;
import com.github.ob_yekt.simpleskills.abyss.AbyssalSolidCaveFormationFeature;
import com.github.ob_yekt.simpleskills.abyss.AbyssalDeadTreeFeature;
import com.github.ob_yekt.simpleskills.abyss.AbyssContent;
import com.github.ob_yekt.simpleskills.abyss.AbyssalFallenKingEntity;
import com.github.ob_yekt.simpleskills.abyss.AbyssalKingItems;
import com.github.ob_yekt.simpleskills.abyss.AbyssalKatanaItems;
import com.github.ob_yekt.simpleskills.abyss.weapon.KatanaStanceManager;
import com.github.ob_yekt.simpleskills.abyss.AbyssWorldgen;
import com.github.ob_yekt.simpleskills.managers.*;
import com.github.ob_yekt.simpleskills.events.EventHandlers;
import com.github.ob_yekt.simpleskills.excavating.ExcavatingManager;
import com.github.ob_yekt.simpleskills.excavating.ModBlocks;
import com.github.ob_yekt.simpleskills.runes.RuneContent;
import com.github.ob_yekt.simpleskills.runes.RuneWorldgen;
import com.github.ob_yekt.simpleskills.runes.RuneMiningManager;
import com.github.ob_yekt.simpleskills.farming.BoneMealMastery;
import com.github.ob_yekt.simpleskills.agility.AgilityManager;
import com.github.ob_yekt.simpleskills.fishing.FishingManager;
import com.github.ob_yekt.simpleskills.fishing.FishingEntities;
import com.github.ob_yekt.simpleskills.fishing.FishingItems;
import com.github.ob_yekt.simpleskills.fishing.FishingSpeciesRegistration;
import com.github.ob_yekt.simpleskills.fishing.FishingFaunaSpawner;
import com.github.ob_yekt.simpleskills.fishing.FishingNaturalSpawns;
import com.github.ob_yekt.simpleskills.enchanting.RuneInfusionMinigameRuntime;
import com.github.ob_yekt.simpleskills.enchanting.RuneInfusionStatePayload;
import com.github.ob_yekt.simpleskills.enchanting.RuneInfusionNetworking;
import com.github.ob_yekt.simpleskills.ui.RankTitleManager;
import com.github.ob_yekt.simpleskills.ui.SkillOverviewManager;
import com.github.ob_yekt.simpleskills.prayer.PrayerManager;
import com.github.ob_yekt.simpleskills.prayer.PrayerVisualEffects;
import com.github.ob_yekt.simpleskills.prayer.PrayerVfxEntity;
import com.github.ob_yekt.simpleskills.shields.GlowstoneShieldLight;
import com.github.ob_yekt.simpleskills.shields.GlowstoneShields;
import com.github.ob_yekt.simpleskills.crafting.CraftingEquipmentManager;
import com.github.ob_yekt.simpleskills.celestial.CelestialAltarContent;
import com.github.ob_yekt.simpleskills.grinder.OreGrinderContent;
import com.github.ob_yekt.simpleskills.celestial.CelestialAltarManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

import net.fabricmc.api.ModInitializer;
import com.github.ob_yekt.simpleskills.prayer.PrayerLighting;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Simpleskills implements ModInitializer {
	public static final String MOD_ID = "simpleskills";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);



	@Override
	public void onInitialize() {
		LOGGER.info("Initializing SimpleSkills mod...");
		SimpleSkillsSounds.register();

		// Register aquatic content before FishingConfig reads the registered species list.
		FishingEntities.register();
		AbyssalFallenKingEntity.register();
		FishingItems.register();
		FishingSpeciesRegistration.register();

		// Blocks must be registered during initialization, before the registries freeze.
		ModBlocks.register();
		RuneContent.register();
		AbyssContent.register();
		AbyssalKingItems.register();
		AbyssalKatanaItems.register();
		AbyssalSolidCaveFormationFeature.registerType();
		AbyssalDeadTreeFeature.registerType();
		RuneMiningManager.register();
		RuneWorldgen.register();
		AbyssWorldgen.register();

		// Escudos de glowstone (itens); precisam existir antes do registro congelar.
		GlowstoneShields.register();
		// O altar e sua essência precisam ser registrados antes da aba criativa e do freeze.
		CelestialAltarContent.register();
		OreGrinderContent.register();
		// Aba própria do SimpleSkills no criativo (depois que os itens existem).
		SimpleSkillsCreativeTab.register();

		GatheringSpeed.registerPayloads();
		ExcavatingManager.registerPayloads();
		FishingManager.registerPayloads();
		CelestialAltarManager.registerPayloads();
		AgilityManager.registerPayloads();
		RankTitleManager.registerPayloads();
		CraftingEquipmentManager.registerPayloads();
		KatanaStanceManager.registerPayloads();
		SkillOverviewManager.registerPayloads();
		PrayerManager.registerPayloads();
		PrayerVfxEntity.register();
		SimpleskillsCommands.registerCommands();
		IronmanManager.init();
		AttributeManager.registerPlayerEvents();
		LoreManager.initialize();
		ConfigManager.initialize();
		FishingNaturalSpawns.register();
		EventHandlers.registerAll();
		DefenseCombat.register();
		AgilityManager.register();
		CraftingEquipmentManager.register();
		KatanaStanceManager.register();
		CelestialAltarManager.register();
		RankTitleManager.registerReceivers();
		SkillOverviewManager.registerReceivers();
		PrayerManager.registerReceivers();
		PrayerVisualEffects.register();
		GlowstoneShieldLight.register();
		BoneMealMastery.register();
		TreeFeller.register();
		ExcavatingManager.register();
		FishingManager.register();
		FishingFaunaSpawner.register();
		RuneInfusionNetworking.registerPayloads();
		PayloadTypeRegistry.clientboundPlay().register(RuneInfusionStatePayload.TYPE, RuneInfusionStatePayload.CODEC);
		RuneInfusionNetworking.registerReceivers();
		RuneInfusionMinigameRuntime.register();

		// Initialize database and setup server lifecycle hooks
		DatabaseManager db = DatabaseManager.getInstance();
		ServerLifecycleEvents.SERVER_STARTING.register(server -> {
			ConfigManager.initialize();
			db.initializeDatabase(server);
			LOGGER.info("Database and config initialized for server.");
		});

		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			PrayerLighting.clearAll();
			GlowstoneShieldLight.clearAll();
		});

		// Fecha em SERVER_STOPPED, depois que o stopServer desconectou os jogadores.
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			db.close();
			LOGGER.info("Database connection closed on server stop.");
		});

		LOGGER.info("SimpleSkills mod initialized successfully!");
	}
}
