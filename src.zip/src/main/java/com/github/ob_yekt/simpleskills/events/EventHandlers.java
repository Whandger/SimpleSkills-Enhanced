package com.github.ob_yekt.simpleskills.events;

import com.github.ob_yekt.simpleskills.Defense;
import com.github.ob_yekt.simpleskills.abyss.item.CrimsonRuneItem;
import com.github.ob_yekt.simpleskills.GatheringSpeed;
import com.github.ob_yekt.simpleskills.Ranged;
import com.github.ob_yekt.simpleskills.Simpleskills;
import com.github.ob_yekt.simpleskills.Skills;
import com.github.ob_yekt.simpleskills.VeinMining;
import com.github.ob_yekt.simpleskills.TreeFeller;
import com.github.ob_yekt.simpleskills.Slaying;
import com.github.ob_yekt.simpleskills.prayer.PrayerManager;
import com.github.ob_yekt.simpleskills.managers.*;
import com.github.ob_yekt.simpleskills.requirements.SkillRequirement;
import com.github.ob_yekt.simpleskills.utils.BlockSkillClassifier;
import com.github.ob_yekt.simpleskills.Ranged;

import com.google.gson.JsonObject;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;

import java.util.Objects;

/**
 * Consolidates all event handlers for the simpleskills mod (block, combat,
 * join/leave, prayer).
 */
public class EventHandlers {

    public static void registerAll() {
        registerBlockHandlers();
        registerCombatHandlers();
        registerJoinLeaveHandlers();
    }

    private static void registerBlockHandlers() {
        // BEFORE block break event
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer serverPlayer)) {
                return true;
            }

            String blockTranslationKey = state.getBlock().getDescriptionId();
            String toolId = "minecraft:air";

            ItemStack mainHandStack = serverPlayer.getMainHandItem();
            if (!mainHandStack.isEmpty()) {
                toolId = BuiltInRegistries.ITEM.getKey(mainHandStack.getItem()).toString();
            }

            // --- 1) Check tool requirement first ---
            SkillRequirement requirement = ConfigManager.getToolRequirement(toolId);
            if (requirement != null) {
                Skills requiredSkill = requirement.getSkill();
                int requiredLevel = requirement.getLevel();
                int requiredPrestige = requirement.getRequiredPrestige();

                int playerLevel = XPManager.getSkillLevel(
                        serverPlayer.getStringUUID(),
                        requiredSkill);

                if (playerLevel < requiredLevel) {
                    serverPlayer.sendSystemMessage(Component.literal(String.format(
                            "§6[simpleskills]§f You need %s level %d to use this tool!",
                            requiredSkill.getDisplayName(),
                            requiredLevel)), true);

                    return false;
                }

                // Prestige gate (optional)
                if (requiredPrestige > 0) {
                    int playerPrestige = DatabaseManager.getInstance()
                            .getPrestige(player.getStringUUID());

                    if (playerPrestige < requiredPrestige) {
                        serverPlayer.sendSystemMessage(Component.literal(String.format(
                                "§6[simpleskills]§f You need Prestige ★%d to use this tool!",
                                requiredPrestige)), true);

                        return false;
                    }
                }
            }

            // --- 2) Then check if block itself has a skill requirement ---
            // Crops bypass tool requirement check
            if (ConfigManager.isCropBlock(blockTranslationKey)) {
                return true;
            }

            // Midas' Touch must intercept the first log before vanilla drops wood;
            // the Tree Feller job then transmutes the entire connected tree consistently.
            if (world instanceof ServerLevel serverLevel
                    && TreeFeller.tryActivateMidasBeforeBreak(serverPlayer, serverLevel, pos, state)) {
                return false;
            }

            return true;
        });

        // AFTER block break event
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.isClientSide() || !(player instanceof ServerPlayer serverPlayer)) {
                return;
            }

            String blockTranslationKey = state.getBlock().getDescriptionId();

            // Transcendent Worldbreaker: automatic 3x3 on non-ore blocks while enabled.
            com.github.ob_yekt.simpleskills.crafting.TranscendentAbilities
                    .tryWorldbreaker(serverPlayer, (ServerLevel) world, pos, state);

            // Check for Silk Touch on ores, melons (before doing anything else)
            if ((blockTranslationKey.contains("_ore")
                    || blockTranslationKey.contains("melon"))
                    && hasSilkTouch(serverPlayer)) {

                Simpleskills.LOGGER.debug(
                        "No XP granted for {} to player {} due to Silk Touch",
                        blockTranslationKey,
                        serverPlayer.getName().getString());

                VeinMining.tryActivate(serverPlayer, (ServerLevel) world, pos, state);
                return;
            }

            // Check if it's a configured farming block
            if (ConfigManager.isCropBlock(blockTranslationKey)) {
                grantFarmingXP(
                        (ServerLevel) world,
                        serverPlayer,
                        pos,
                        state,
                        blockTranslationKey);
                return;
            }

            // Determine skill: prefer explicit config; otherwise infer by mineable tool tag
            Skills relevantSkill = BlockSkillClassifier.classify(state);
            Integer overrideXP = ConfigManager.getBlockXPOverride(blockTranslationKey);

            if (relevantSkill == null) {
                VeinMining.tryActivate(serverPlayer, (ServerLevel) world, pos, state);
                return;
            }

            // Grant XP for non-farming skills
            if (relevantSkill != Skills.FARMING) {
                int xp;

                if (overrideXP != null) {
                    xp = overrideXP;
                } else {
                    // Hardness-based default: hardness 1.5 -> 100 XP
                    float hardness = state.getDestroySpeed(world, pos);
                    xp = Math.max(0, Math.round(hardness * (100.0f / 1.5f)));
                }

                XPManager.addXPWithNotification(serverPlayer, relevantSkill, xp);
            }

            // Use the updated Mining level after the original block's XP has been granted.
            VeinMining.tryActivate(serverPlayer, (ServerLevel) world, pos, state);

            // Tree Feller uses the same post-break path for Woodcutting logs.
            TreeFeller.tryActivate(serverPlayer, (ServerLevel) world, pos, state);
        });
    }

    public static void grantFarmingXP(
            ServerLevel world,
            ServerPlayer serverPlayer,
            BlockPos pos,
            BlockState state,
            String blockTranslationKey) {
        ConfigManager.CropConfig cropConfig = ConfigManager.getCropConfig(blockTranslationKey);

        if (cropConfig == null) {
            return;
        }

        boolean isMatured = false;

        switch (cropConfig.ageProperty()) {
            case "AGE_7":
                if (state.hasProperty(BlockStateProperties.AGE_7)) {
                    int age = state.getValue(BlockStateProperties.AGE_7);
                    isMatured = age >= cropConfig.maturityAge();
                }
                break;

            case "AGE_3":
                if (state.hasProperty(BlockStateProperties.AGE_3)) {
                    int age = state.getValue(BlockStateProperties.AGE_3);
                    isMatured = age >= cropConfig.maturityAge();
                }
                break;

            case "AGE_2":
                if (state.hasProperty(BlockStateProperties.AGE_2)) {
                    int age = state.getValue(BlockStateProperties.AGE_2);
                    isMatured = age >= cropConfig.maturityAge();
                }
                break;

            case "AGE_5":
                if (state.hasProperty(BlockStateProperties.AGE_5)) {
                    int age = state.getValue(BlockStateProperties.AGE_5);
                    isMatured = age >= cropConfig.maturityAge();
                }
                break;

            case "AGE_25":
                if (state.hasProperty(BlockStateProperties.AGE_25)) {
                    int age = state.getValue(BlockStateProperties.AGE_25);
                    isMatured = age >= cropConfig.maturityAge();
                }
                break;

            case "NONE":
                isMatured = true;
                break;

            default:
                Simpleskills.LOGGER.warn(
                        "Unknown age property '{}' for crop {}",
                        cropConfig.ageProperty(),
                        blockTranslationKey);
                return;
        }

        if (!isMatured) {
            return;
        }

        int xp = cropConfig.xp();

        XPManager.addXPWithNotification(serverPlayer, Skills.FARMING, xp);

        applyBonusDrops(world, serverPlayer, pos, state, blockTranslationKey);

        Simpleskills.LOGGER.debug(
                "Granted {} XP for harvesting {} to player {}",
                xp,
                blockTranslationKey,
                serverPlayer.getName().getString());
    }

    /**
     * Harvest Bonus chance: +1% per Farming level, capped at 99%. This is the original formula, moved
     * into a method so the tab menu can show the exact value the harvest roll uses (no second formula).
     */
    public static double getHarvestBonusChance(int farmingLevel) {
        return Math.min(farmingLevel, 99) / 100.0;
    }

    private static void applyBonusDrops(
            ServerLevel world,
            ServerPlayer player,
            BlockPos pos,
            BlockState state,
            String blockTranslationKey) {
        int farmingLevel = XPManager.getSkillLevel(
                player.getStringUUID(),
                Skills.FARMING);

        double dropChance = getHarvestBonusChance(farmingLevel);

        if (world.getRandom().nextDouble() < dropChance) {
            spawnBonusDrops(world, pos, state);

            Simpleskills.LOGGER.debug(
                    "Granted bonus drops to {} for {} (farming level: {})",
                    player.getName().getString(),
                    blockTranslationKey,
                    farmingLevel);
        }
    }

    private static void spawnBonusDrops(
            ServerLevel world,
            BlockPos pos,
            BlockState state) {
        java.util.List<ItemStack> drops = net.minecraft.world.level.block.Block.getDrops(
                state,
                world,
                pos,
                null);

        Vec3 dropPos = new Vec3(
                pos.getX() + 0.5,
                pos.getY() + 0.5,
                pos.getZ() + 0.5);

        for (ItemStack drop : drops) {
            if (drop.isEmpty()) {
                continue;
            }

            ItemStack bonus = drop.copy();

            ItemEntity itemEntity = new ItemEntity(
                    world,
                    dropPos.x,
                    dropPos.y,
                    dropPos.z,
                    bonus);

            itemEntity.setDeltaMovement(
                    (world.getRandom().nextDouble() - 0.5) * 0.1,
                    world.getRandom().nextDouble() * 0.1,
                    (world.getRandom().nextDouble() - 0.5) * 0.1);

            world.addFreshEntity(itemEntity);
        }
    }

    private static void registerCombatHandlers() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClientSide()
                    || !(player instanceof ServerPlayer serverPlayer)
                    || !(entity instanceof LivingEntity)) {
                return InteractionResult.PASS;
            }

            ItemStack weapon = serverPlayer.getItemInHand(hand);

            if (weapon.isEmpty()) {
                return InteractionResult.PASS;
            }

            String weaponId = BuiltInRegistries.ITEM
                    .getKey(weapon.getItem())
                    .toString();

            SkillRequirement requirement = ConfigManager.getWeaponRequirement(weaponId);

            if (requirement == null) {
                return InteractionResult.PASS;
            }

            Skills skill = requirement.getSkill();

            int playerLevel = XPManager.getSkillLevel(
                    serverPlayer.getStringUUID(),
                    skill);

            if (playerLevel < requirement.getLevel()) {
                serverPlayer.sendSystemMessage(Component.literal(String.format(
                        "§6[simpleskills]§f You need %s level %d to use this weapon!",
                        skill.getDisplayName(),
                        requirement.getLevel())), true);

                return InteractionResult.FAIL;
            }

            int requiredPrestige = requirement.getRequiredPrestige();

            if (requiredPrestige > 0) {
                int playerPrestige = DatabaseManager.getInstance()
                        .getPrestige(player.getStringUUID());

                if (playerPrestige < requiredPrestige) {
                    serverPlayer.sendSystemMessage(Component.literal(String.format(
                            "§6[simpleskills]§f You need Prestige ★%d to use this weapon!",
                            requiredPrestige)), true);

                    return InteractionResult.FAIL;
                }
            }

            return InteractionResult.PASS;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClientSide()
                    || !(player instanceof ServerPlayer serverPlayer)) {
                return InteractionResult.PASS;
            }

            ItemStack stack = player.getItemInHand(hand);

            if (stack.getItem() instanceof CrimsonRuneItem) {
                return PrayerManager.castWithCrimsonRune(serverPlayer)
                        ? InteractionResult.SUCCESS
                        : InteractionResult.PASS;
            }

            if (stack.isEmpty()) {
                return InteractionResult.PASS;
            }

            String itemId = BuiltInRegistries.ITEM
                    .getKey(stack.getItem())
                    .toString();

            SkillRequirement requirement = ConfigManager.getWeaponRequirement(itemId);

            if (requirement == null) {
                return InteractionResult.PASS;
            }

            Skills skill = requirement.getSkill();

            int playerLevel = XPManager.getSkillLevel(
                    serverPlayer.getStringUUID(),
                    skill);

            if (playerLevel < requirement.getLevel()) {
                serverPlayer.sendSystemMessage(Component.literal(String.format(
                        "§6[simpleskills]§f You need %s level %d to use this weapon!",
                        skill.getDisplayName(),
                        requirement.getLevel())), true);

                return InteractionResult.FAIL;
            }

            int requiredPrestige = requirement.getRequiredPrestige();

            if (requiredPrestige > 0) {
                int playerPrestige = DatabaseManager.getInstance()
                        .getPrestige(player.getStringUUID());

                if (playerPrestige < requiredPrestige) {
                    serverPlayer.sendSystemMessage(Component.literal(String.format(
                            "§6[simpleskills]§f You need Prestige ★%d to use this weapon!",
                            skill.getDisplayName(),
                            requirement.getLevel())), true);

                    return InteractionResult.FAIL;
                }
            }

            return InteractionResult.PASS;
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity.level().isClientSide() || amount <= 0) {
                return true;
            }

            // Duplicated Ranged projectiles must not grant additional XP.
            if (source.getDirectEntity() instanceof Projectile projectile
                    && Ranged.isDuplicateProjectile(projectile)) {
                return true;
            }

            if (source.is(net.minecraft.world.damagesource.DamageTypes.EXPLOSION)
                    || source.is(net.minecraft.world.damagesource.DamageTypes.PLAYER_EXPLOSION)) {
                return true;
            }

            // Firework rockets never grant combat XP.
            // This check is independent of who launched the rocket.
            if (source.getDirectEntity() instanceof FireworkRocketEntity) {
                return true;
            }

            // Dano de magia do Prayer não concede XP de combate (Slaying/Ranged).
            // O XP do Prayer vem do cast, em PrayerManager.cast.
            if (PrayerManager.isApplyingPrayerDamage()) {
                return true;
            }

            JsonObject config = ConfigManager.getCombatConfig();

            float xpPerDamageSlaying = config.get("slaying_xp_per_damage") != null
                    ? config.get("slaying_xp_per_damage").getAsFloat()
                    : 100.0f;

            float xpPerDamageRanged = config.get("ranged_xp_per_damage") != null
                    ? config.get("ranged_xp_per_damage").getAsFloat()
                    : 100.0f;

            float minDamageSlaying = config.get("slaying_min_damage_threshold") != null
                    ? config.get("slaying_min_damage_threshold").getAsFloat()
                    : 2.0f;

            float minDamageRanged = config.get("ranged_min_damage_threshold") != null
                    ? config.get("ranged_min_damage_threshold").getAsFloat()
                    : 2.0f;

            if (entity instanceof LivingEntity target
                    && !(target instanceof Player)
                    && !(entity instanceof net.minecraft.world.entity.decoration.ArmorStand)) {

                ServerPlayer attacker = null;
                Skills skill = null;
                float xpMultiplier = 0.0f;
                float minDamage = 0.0f;
                int xp = 0;

                // Check projectiles before checking the responsible entity.
                // This prevents projectile damage from being mistaken for melee damage.
                if (source.getDirectEntity() instanceof Projectile projectile) {

                    String projectileId = BuiltInRegistries.ENTITY_TYPE
                            .getKey(projectile.getType())
                            .toString();

                    boolean isRangedProjectile = projectileId.equals("minecraft:arrow")
                            || projectileId.equals("minecraft:spectral_arrow")
                            || projectileId.equals("minecraft:trident");

                    if (isRangedProjectile
                            && projectile.getOwner() instanceof ServerPlayer projectileOwner) {

                        attacker = projectileOwner;
                        skill = Skills.RANGED;
                        xpMultiplier = xpPerDamageRanged;
                        minDamage = minDamageRanged;

                        xp = (int) (amount * xpMultiplier);
                    }
                }
                // Preserve the original melee XP logic.
                else if (source.getEntity() instanceof ServerPlayer meleeAttacker) {
                    attacker = meleeAttacker;

                    ItemStack weapon = attacker.getMainHandItem();

                    String weaponId = weapon.isEmpty()
                            ? "minecraft:empty"
                            : BuiltInRegistries.ITEM.getKey(weapon.getItem()).toString();

                    SkillRequirement requirement = ConfigManager.getWeaponRequirement(weaponId);

                    skill = (requirement != null
                            && requirement.getSkill() == Skills.RANGED)
                                    ? Skills.RANGED
                                    : Skills.SLAYING;

                    xpMultiplier = skill == Skills.RANGED
                            ? xpPerDamageRanged
                            : xpPerDamageSlaying;

                    minDamage = skill == Skills.RANGED
                            ? minDamageRanged
                            : minDamageSlaying;

                    xp = (int) (amount * xpMultiplier);
                }

                if (attacker != null && amount >= minDamage) {
                    XPManager.addXPWithNotification(attacker, skill, xp);

                    Simpleskills.LOGGER.debug(
                            "Granted {} XP in {} to {} for dealing {} damage to {}",
                            xp,
                            skill.getId(),
                            attacker.getName().getString(),
                            amount,
                            target.getType().toString());
                }
            }

            return true;
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register(
                (entity, source, originalAmount, actualAmount, blocked) -> {
                    if (entity.level().isClientSide()) {
                        return;
                    }

                    if (source.is(net.minecraft.world.damagesource.DamageTypes.EXPLOSION)
                            || source.is(net.minecraft.world.damagesource.DamageTypes.PLAYER_EXPLOSION)) {
                        return;
                    }

                    if (entity instanceof ServerPlayer defender
                            && source.getEntity() instanceof LivingEntity attacker
                            && !(attacker instanceof Player)) {

                        // A confirmed parry was already awarded by the shield-block callback.
                        if (com.github.ob_yekt.simpleskills.DefenseCombat.consumeParryXp(defender, attacker, originalAmount)) {
                            return;
                        }

                        JsonObject config = ConfigManager.getCombatConfig();

                        float xpPerDamageDefense = config.get("defense_xp_per_damage") != null
                                ? config.get("defense_xp_per_damage").getAsFloat()
                                : 100.0f;

                        float minDamageDefense = config.get("defense_min_damage_threshold") != null
                                ? config.get("defense_min_damage_threshold").getAsFloat()
                                : 2.0f;

                        float armorMultiplierPerPiece = config.get("defense_xp_armor_multiplier_per_piece") != null
                                ? config.get("defense_xp_armor_multiplier_per_piece").getAsFloat()
                                : 0.25f;

                        float shieldXPMultiplier = config.get("defense_shield_xp_multiplier") != null
                                ? config.get("defense_shield_xp_multiplier").getAsFloat()
                                : 0.3f;

                        if (originalAmount >= minDamageDefense) {
                            boolean wasBlocked = blocked
                                    || (originalAmount > actualAmount
                                            && defender.isBlocking()
                                            && defender.getUseItem()
                                                    .is(com.github.ob_yekt.simpleskills.shields.GlowstoneShields.SHIELDS));

                            if (wasBlocked) {
                                int xp = (int) (originalAmount
                                        * xpPerDamageDefense
                                        * shieldXPMultiplier);

                                XPManager.addXPWithNotification(
                                        defender,
                                        Skills.DEFENSE,
                                        xp);

                                Simpleskills.LOGGER.debug(
                                        "Granted {} XP in {} to {} for blocking {} damage from {} with shield",
                                        xp,
                                        Skills.DEFENSE.getId(),
                                        defender.getName().getString(),
                                        originalAmount,
                                        attacker.getType().toString());
                            } else {
                                int armorCount = 0;

                                for (EquipmentSlot slot : EquipmentSlot.values()) {
                                    if (slot.isArmor()
                                            && !defender.getItemBySlot(slot).isEmpty()) {
                                        armorCount++;
                                    }
                                }

                                if (armorCount > 0) {
                                    float armorMultiplier = armorCount * armorMultiplierPerPiece;

                                    int xp = (int) (actualAmount
                                            * xpPerDamageDefense
                                            * armorMultiplier);

                                    XPManager.addXPWithNotification(
                                            defender,
                                            Skills.DEFENSE,
                                            xp);

                                    Simpleskills.LOGGER.debug(
                                            "Granted {} XP in {} to {} for taking {} damage from {} with {} armor pieces",
                                            xp,
                                            Skills.DEFENSE.getId(),
                                            defender.getName().getString(),
                                            actualAmount,
                                            attacker.getType().toString(),
                                            armorCount);
                                }
                            }
                        }
                    }
                });
    }

    private static void registerJoinLeaveHandlers() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();

            if (player == null) {
                Simpleskills.LOGGER.warn("Null player in join event.");
                return;
            }

            String playerUuid = player.getStringUUID();
            String playerName = player.getName().getString();

            DatabaseManager db = DatabaseManager.getInstance();

            db.ensurePlayerInitialized(playerUuid);
            db.updatePlayerName(playerUuid, playerName);

            boolean isForceIronman = ConfigManager.isForceIronmanModeEnabled();
            boolean isCurrentlyIronman = db.isPlayerInIronmanMode(playerUuid);

            if (isForceIronman) {
                if (!isCurrentlyIronman) {
                    db.setIronmanMode(playerUuid, true);

                    Simpleskills.LOGGER.info(
                            "Force-enabled Ironman Mode for {} due to server config.",
                            playerName);
                }

                IronmanManager.applyIronmanMode(player);
            } else if (isCurrentlyIronman) {
                IronmanManager.applyIronmanMode(player);
            }

            AttributeManager.refreshAllAttributes(player);


            com.github.ob_yekt.simpleskills.managers.NamePrefixManager
                    .updatePlayerNameDecorations(player);

            // Explicitly load and synchronize Gathering Speed levels on join.
            int miningLevel = XPManager.getSkillLevel(playerUuid, Skills.MINING);
            int woodcuttingLevel = XPManager.getSkillLevel(playerUuid, Skills.WOODCUTTING);
            int excavatingLevel = XPManager.getSkillLevel(playerUuid, Skills.EXCAVATING);

            GatheringSpeed.setServerLevel(player, Skills.MINING, miningLevel);
            GatheringSpeed.setServerLevel(player, Skills.WOODCUTTING, woodcuttingLevel);
            GatheringSpeed.setServerLevel(player, Skills.EXCAVATING, excavatingLevel);

            if (isForceIronman) {
                player.sendSystemMessage(
                        Component.literal(
                                "§6[simpleskills]§f §cThis server is running in permanent Ironman Mode.")
                                .withStyle(ChatFormatting.RED),
                        false);
            }

            Simpleskills.LOGGER.debug(
                    "Player joined and initialized: {} (Ironman: {}, Forced: {})",
                    playerName,
                    isCurrentlyIronman || isForceIronman,
                    isForceIronman);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer player = handler.getPlayer();

            if (player == null) {
                Simpleskills.LOGGER.warn("Null player in disconnect event.");
                return;
            }

            String playerName = player.getName().getString();

            AttributeManager.clearSkillAttributes(player);
            AttributeManager.clearIronmanAttributes(player);


            GatheringSpeed.clearServerLevels(player.getUUID());
            Slaying.clearServerLevels(player.getUUID());
            Defense.clearServerLevels(player.getUUID());

            // Clear Ranged cache when the player disconnects.
            Ranged.clearServerLevels(player.getUUID());

            Simpleskills.LOGGER.debug(
                    "Player disconnected: {}",
                    playerName);
        });
    }

    private static boolean hasSilkTouch(ServerPlayer player) {
        ItemStack toolStack = player.getItemBySlot(EquipmentSlot.MAINHAND);

        var enchantmentRegistry = Objects.requireNonNull(player.level().getServer())
                .registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT);

        Holder<Enchantment> silkTouchEntry = enchantmentRegistry
                .get(Enchantments.SILK_TOUCH)
                .orElse(null);

        if (silkTouchEntry == null) {
            Simpleskills.LOGGER.warn(
                    "Silk Touch enchantment not found in registry for player {}",
                    player.getName().getString());

            return false;
        }

        return EnchantmentHelper.getItemEnchantmentLevel(
                silkTouchEntry,
                toolStack) > 0;
    }
}
