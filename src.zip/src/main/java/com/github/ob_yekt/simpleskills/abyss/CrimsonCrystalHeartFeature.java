package com.github.ob_yekt.simpleskills.abyss;

import com.github.ob_yekt.simpleskills.Simpleskills;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;

/**
 * Generates the hollow, ground-rooted centerpiece of the Crimson Crystal Caverns.
 * The silhouette is a mineral cluster: one tall central blade, four to seven separate
 * diagonal blades, and a low angular shell containing a large arched entrance.
 */
public record CrimsonCrystalHeartFeature() implements Feature {
    public static final MapCodec<CrimsonCrystalHeartFeature> CODEC =
            MapCodec.unit(new CrimsonCrystalHeartFeature());

    private static final int SHELL_HEIGHT = 30;
    private static final int MAIN_SPIRE_START = 23;
    private static final int MAIN_SPIRE_MAX_HEIGHT = 105;
    private static final int CHAMBER_HALF_WIDTH = 10;
    private static final int CHAMBER_HALF_DEPTH = 8;
    private static final int CHAMBER_ARCH_SPRING = 14;
    private static final int CHAMBER_ARCH_HEIGHT = 10;
    private static final int ENTRANCE_ARCH_SPRING = 14;
    private static final int ENTRANCE_ARCH_HEIGHT = 10;
    private static final Direction[] HORIZONTAL = {
            Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST
    };

    public static void registerType() {
        Registry.register(BuiltInRegistries.FEATURE_TYPE,
                Identifier.fromNamespaceAndPath(Simpleskills.MOD_ID, "crimson_crystal_heart"), CODEC);
    }

    @Override
    public MapCodec<? extends Feature> codec() {
        return CODEC;
    }

    @Override
    public boolean place(WorldGenLevel level, ChunkGenerator chunkGenerator, RandomSource random, BlockPos origin) {
        if (!AbyssWorldgen.isOverworld(level) || !AbyssWorldgen.isAbyssY(origin.getY())) return false;

        AbyssWorldgen.CrimsonCrystalRegion region = AbyssWorldgen.crimsonRegionAt(
                origin.getX(), origin.getZ(), level.getSeed());
        if (region == null) return false;

        int sourceChunkX = origin.getX() >> 4;
        int sourceChunkZ = origin.getZ() >> 4;
        if (sourceChunkX != Math.floorDiv(region.centerX(), 16)
                || sourceChunkZ != Math.floorDiv(region.centerZ(), 16)) {
            return false;
        }

        GroundAnchor ground = findGroundAnchor(level, region.centerX(), region.centerZ());
        if (ground == null) return false;

        // Start at the actual floor block. The bottom crystal layer replaces the surface
        // rock, while the buttresses sink into the blocks underneath it.
        BlockPos base = new BlockPos(ground.x, ground.y, ground.z);
        int availableMainHeight = AbyssWorldgen.MAX_Y - (base.getY() + MAIN_SPIRE_START + 1) - 2;
        int mainHeight = Math.min(MAIN_SPIRE_MAX_HEIGHT, availableMainHeight);
        if (mainHeight < 42) return false;

        Entrance entrance = findCaveEntrance(level, base);
        Direction rear = entrance.direction.getOpposite();
        BlockPos marker = base.relative(rear, 12).above(MAIN_SPIRE_START + 1 + mainHeight - 2);
        if (isCrystalBlock(level.getBlockState(marker))) return false;

        buildAngularHollowBase(level, base, entrance.direction, random);
        buildCentralBlade(level, base, rear, mainHeight, random);
        growSideBlades(level, base, entrance.direction, random);
        carveInteriorChamber(level, base, entrance);
        buildEntranceArchFrame(level, base, entrance, random);
        buildArenaFloor(level, base, entrance);
        addInteriorCrystals(level, base, entrance, random);
        addExteriorBudding(level, base, random);
        return true;
    }

    /**
     * Finds the exposed natural floor directly below the landmark center. The crystal is
     * skipped if no real floor exists there, rather than falling back to a floating position.
     */
    private static GroundAnchor findGroundAnchor(WorldGenLevel level, int centerX, int centerZ) {
        GroundAnchor best = null;
        double bestScore = Double.MAX_VALUE;
        int highestUsableFloor = AbyssWorldgen.MAX_Y - MAIN_SPIRE_START - 45 - 3;

        for (int y = highestUsableFloor; y >= AbyssWorldgen.MIN_Y + 2; y--) {
            BlockPos floor = new BlockPos(centerX, y, centerZ);
            if (!isNaturalRock(level.getBlockState(floor))) continue;
            if (!level.getBlockState(floor.above()).isAir()
                    || !level.getBlockState(floor.above(2)).isAir()
                    || !level.getBlockState(floor.above(3)).isAir()) {
                continue;
            }

            int clearHeight = 0;
            for (int up = 1; up <= 48; up++) {
                if (!level.getBlockState(floor.above(up)).isAir()) break;
                clearHeight++;
            }
            if (clearHeight < 18) continue;

            double score = Math.abs(y - (-218)) * 0.12 - Math.min(clearHeight, 40) * 0.10;
            if (score < bestScore) {
                bestScore = score;
                best = new GroundAnchor(centerX, y, centerZ);
            }
        }

        // Never fall back to a guessed Y coordinate: if there is no floor at the landmark,
        // skip generation instead of producing another floating crystal.
        return best;
    }

    /** Builds a sharply faceted, hollow basal shell with a low, broad footprint. */
    private static void buildAngularHollowBase(WorldGenLevel level, BlockPos base,
                                              Direction entranceDirection, RandomSource random) {
        for (int dy = 0; dy <= SHELL_HEIGHT; dy++) {
            int y = base.getY() + dy;
            if (!AbyssWorldgen.isAbyssY(y)) break;

            double outerX = shellRadiusAt(dy);
            double outerZ = outerX * 0.82;
            boolean entranceRunsAlongX = entranceDirection == Direction.EAST || entranceDirection == Direction.WEST;
            double innerXBase = entranceRunsAlongX ? CHAMBER_HALF_DEPTH + 0.8 : CHAMBER_HALF_WIDTH + 0.8;
            double innerZBase = entranceRunsAlongX ? CHAMBER_HALF_WIDTH + 0.8 : CHAMBER_HALF_DEPTH + 0.8;
            double innerX = dy <= 22 ? innerXBase : Math.max(5.0, innerXBase - (dy - 22) * 0.55);
            double innerZ = dy <= 22 ? innerZBase : Math.max(4.0, innerZBase - (dy - 22) * 0.48);
            int boundX = (int) Math.ceil(outerX + 1.0);
            int boundZ = (int) Math.ceil(outerZ + 1.0);

            for (int dx = -boundX; dx <= boundX; dx++) {
                for (int dz = -boundZ; dz <= boundZ; dz++) {
                    double outerMetric = octagonalMetric(dx / outerX, dz / outerZ);
                    double innerMetric = octagonalMetric(dx / innerX, dz / innerZ);
                    double facetNoise = 0.035 * Math.sin(dx * 0.71 + dz * 0.37 + dy * 0.29)
                            + 0.02 * Math.cos(dx * 0.23 - dz * 0.83);
                    if (outerMetric > 1.0 + facetNoise || innerMetric < 0.94) continue;

                    BlockPos target = base.offset(dx, dy, dz);
                    BlockState existing = level.getBlockState(target);
                    if (!isNaturalOrAir(existing) && !isCrystalBlock(existing)) continue;
                    level.setBlock(target, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
                }
            }
        }

        // Eight uneven buttresses continue the shell into nearby floor blocks. These roots
        // make the base look embedded in the ground, not like a structure placed on top of it.
        buildGroundButtresses(level, base, random);
    }

    private static double shellRadiusAt(int dy) {
        if (dy <= 5) return 18.5;
        if (dy <= 14) return 20.5;
        if (dy <= 22) return 19.0;
        if (dy <= 27) return 18.0;
        return 14.0 - (dy - 27) * 0.80;
    }

    private static void buildGroundButtresses(WorldGenLevel level, BlockPos base, RandomSource random) {
        for (int i = 0; i < 8; i++) {
            double angle = (Math.PI * 2.0 * i / 8.0) + (random.nextDouble() - 0.5) * 0.18;
            int startX = (int) Math.round(Math.cos(angle) * 13.5);
            int startZ = (int) Math.round(Math.sin(angle) * 11.0);
            int length = 5 + random.nextInt(5);
            for (int step = 0; step <= length; step++) {
                double progress = step / (double) length;
                int x = (int) Math.round(startX + Math.cos(angle) * step * 0.72);
                int z = (int) Math.round(startZ + Math.sin(angle) * step * 0.72);
                int y = base.getY() - 2 + (int) Math.round(4.0 * progress);
                int radius = Math.max(1, (int) Math.round(3.0 * (1.0 - progress) + 0.8));
                for (int ox = -radius; ox <= radius; ox++) {
                    for (int oz = -radius; oz <= radius; oz++) {
                        if (Math.abs(ox) + Math.abs(oz) > radius + 1) continue;
                        BlockPos target = base.offset(x + ox, y, z + oz);
                        if (isNaturalOrAir(level.getBlockState(target))) {
                            level.setBlock(target, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
                        }
                    }
                }
            }
        }
    }

    /** The tallest crystal is one long, angular blade rising from the rear of the hollow base. */
    private static void buildCentralBlade(WorldGenLevel level, BlockPos base, Direction rear,
                                          int height, RandomSource random) {
        // Root the tallest blade in the rear wall of the shell, outside the hollow chamber.
        BlockPos start = base.relative(rear, 12).above(MAIN_SPIRE_START + 1);
        double leanX = (random.nextDouble() - 0.5) * 0.10;
        double leanZ = (random.nextDouble() - 0.5) * 0.10;

        for (int step = 0; step <= height; step++) {
            double progress = step / (double) height;
            double radius;
            if (progress < 0.16) {
                radius = 7.0 - progress * 4.0;
            } else {
                radius = Math.max(0.68, 6.35 * Math.pow((1.0 - progress) / 0.84, 0.88));
            }

            BlockPos slice = new BlockPos(
                    (int) Math.round(start.getX() + leanX * step),
                    start.getY() + step,
                    (int) Math.round(start.getZ() + leanZ * step));
            placeFacetedSlice(level, slice, radius, 0.06 * Math.sin(step * 0.31));
        }
    }

    /** Grows four to seven distinct diagonal blades from the sides of the basal cluster. */
    private static void growSideBlades(WorldGenLevel level, BlockPos base,
                                       Direction entranceDirection, RandomSource random) {
        int count = 4 + random.nextInt(4);
        double entranceAngle = Math.atan2(entranceDirection.getStepZ(), entranceDirection.getStepX());
        double phase = entranceAngle + Math.PI / count;

        for (int i = 0; i < count; i++) {
            double angle = phase + i * (Math.PI * 2.0 / count);
            if (angularDistance(angle, entranceAngle) < 0.62) {
                angle += (i % 2 == 0 ? 1.0 : -1.0) * 0.78;
            }

            double worldX = Math.cos(angle);
            double worldZ = Math.sin(angle);
            Direction across = entranceDirection.getClockWise();
            double alongComponent = Math.abs(worldX * entranceDirection.getStepX()
                    + worldZ * entranceDirection.getStepZ());
            double acrossComponent = Math.abs(worldX * across.getStepX() + worldZ * across.getStepZ());
            double depthLimit = CHAMBER_HALF_DEPTH / Math.max(0.001, alongComponent);
            double sideLimit = CHAMBER_HALF_WIDTH / Math.max(0.001, acrossComponent);
            double boundaryRadius = Math.min(depthLimit, sideLimit);

            // Start just outside the chamber wall so the blade remains rooted after carving.
            int startRadius = (int) Math.ceil(boundaryRadius + 0.9);
            double horizontal = 0.22 + random.nextDouble() * 0.03;
            double vertical = Math.sqrt(1.0 - horizontal * horizontal);
            double axisX = worldX * horizontal;
            double axisY = vertical;
            double axisZ = worldZ * horizontal;
            int startY = 7 + random.nextInt(12);
            BlockPos start = base.offset(
                    (int) Math.round(worldX * startRadius),
                    startY,
                    (int) Math.round(worldZ * startRadius));
            int length = 27 + random.nextInt(3);
            double radius = 3.0 + random.nextDouble() * 0.3;
            growDiagonalBlade(level, start, axisX, axisY, axisZ, length, radius, random);
        }
    }

    private static void growDiagonalBlade(WorldGenLevel level, BlockPos start,
                                          double axisX, double axisY, double axisZ,
                                          int length, double baseRadius, RandomSource random) {
        for (int step = 0; step <= length; step++) {
            double progress = step / (double) length;
            double radius = Math.max(0.68, baseRadius * Math.pow(1.0 - progress, 0.90));
            BlockPos slice = new BlockPos(
                    (int) Math.round(start.getX() + axisX * step),
                    (int) Math.round(start.getY() + axisY * step),
                    (int) Math.round(start.getZ() + axisZ * step));
            if (!AbyssWorldgen.isAbyssY(slice.getY())) break;

            int bound = (int) Math.ceil(radius + 1.0);
            for (int ox = -bound; ox <= bound; ox++) {
                for (int oy = -bound; oy <= bound; oy++) {
                    for (int oz = -bound; oz <= bound; oz++) {
                        double axial = ox * axisX + oy * axisY + oz * axisZ;
                        if (Math.abs(axial) > 0.78) continue;

                        double px = ox - axial * axisX;
                        double py = oy - axial * axisY;
                        double pz = oz - axial * axisZ;
                        double largest = Math.max(Math.abs(px), Math.max(Math.abs(py), Math.abs(pz)));
                        double smallest = Math.min(Math.abs(px), Math.min(Math.abs(py), Math.abs(pz)));
                        double middle = Math.abs(px) + Math.abs(py) + Math.abs(pz) - largest - smallest;
                        double facet = largest + middle * 0.30 + smallest * 0.10;
                        if (facet > radius + 0.08 * Math.sin(step * 0.41 + ox * 0.7 + oz * 0.6)) continue;

                        BlockPos target = slice.offset(ox, oy, oz);
                        BlockState existing = level.getBlockState(target);
                        if (!AbyssWorldgen.isAbyssY(target.getY())
                                || !AbyssWorldgen.isCrimsonCrystalBiome(target.getX(), target.getZ(), level.getSeed())
                                || (!isNaturalOrAir(existing) && !isCrystalBlock(existing))) {
                            continue;
                        }
                        level.setBlock(target, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
                    }
                }
            }

            if (step > 5 && step < length - 3 && step % 7 == 0 && random.nextFloat() < 0.8F) {
                Direction face = Math.abs(axisX) > Math.abs(axisZ)
                        ? (axisX >= 0.0 ? Direction.EAST : Direction.WEST)
                        : (axisZ >= 0.0 ? Direction.SOUTH : Direction.NORTH);
                BlockPos support = slice.relative(face, Math.max(1, (int) Math.floor(radius * 0.7)));
                placeAttachedBud(level, support, face, random);
            }
        }
    }

    private static void placeFacetedSlice(WorldGenLevel level, BlockPos center, double radius, double noise) {
        int bound = (int) Math.ceil(radius + 1.0);
        for (int dx = -bound; dx <= bound; dx++) {
            for (int dz = -bound; dz <= bound; dz++) {
                double metric = octagonalMetric(dx / radius, dz / radius);
                double edge = 1.0 + noise + 0.035 * Math.sin(dx * 0.8 + dz * 0.6);
                if (metric > edge) continue;
                BlockPos target = center.offset(dx, 0, dz);
                BlockState existing = level.getBlockState(target);
                if (isNaturalOrAir(existing) || isCrystalBlock(existing)) {
                    level.setBlock(target, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
                }
            }
        }
    }

    /** Carves a tall interior chamber and a monumental arched doorway through the shell. */
    private static void carveInteriorChamber(WorldGenLevel level, BlockPos base, Entrance entrance) {
        Direction forward = entrance.direction;
        Direction across = forward.getClockWise();

        // Main room: broad lower chamber with a vaulted, faceted roof.
        for (int dy = 2; dy <= 24; dy++) {
            int halfWidth = archHalfWidth(dy, CHAMBER_HALF_WIDTH, CHAMBER_ARCH_SPRING, CHAMBER_ARCH_HEIGHT);
            for (int side = -halfWidth; side <= halfWidth; side++) {
                for (int depth = -CHAMBER_HALF_DEPTH; depth <= CHAMBER_HALF_DEPTH; depth++) {
                    BlockPos target = base.above(dy).relative(across, side).relative(forward, depth);
                    carveBlock(level, target);
                }
            }
        }

        // The opening extends beyond the front face, so the chamber is visibly accessible.
        for (int distance = 4; distance <= 24; distance++) {
            for (int dy = 1; dy <= 24; dy++) {
                int halfWidth = archHalfWidth(dy, 10, ENTRANCE_ARCH_SPRING, ENTRANCE_ARCH_HEIGHT);
                for (int side = -halfWidth; side <= halfWidth; side++) {
                    BlockPos target = base.relative(forward, distance).relative(across, side).above(dy);
                    carveBlock(level, target);
                }
            }
        }
    }

    private static int archHalfWidth(int y, int lowerWidth, int springHeight, int archHeight) {
        if (y <= springHeight) return lowerWidth;
        double progress = (y - springHeight) / (double) archHeight;
        if (progress >= 1.0) return 0;
        return Math.max(0, (int) Math.floor(lowerWidth * Math.sqrt(1.0 - progress * progress)));
    }

    private static void buildEntranceArchFrame(WorldGenLevel level, BlockPos base, Entrance entrance, RandomSource random) {
        Direction forward = entrance.direction;
        Direction across = forward.getClockWise();
        // Place the frame inside the shell wall, not beyond its outer surface.
        int frameDistance = (forward == Direction.EAST || forward == Direction.WEST) ? 12 : 11;

        // Thick vertical legs on both sides of the doorway.
        for (int dy = 0; dy <= ENTRANCE_ARCH_SPRING; dy++) {
            for (int sideSign : new int[]{-1, 1}) {
                for (int thickness = -1; thickness <= 1; thickness++) {
                    BlockPos frame = base.relative(forward, frameDistance + thickness)
                            .relative(across, sideSign * 11).above(dy);
                    placeCrystalIfReplaceable(level, frame);
                    if (dy > 3 && dy % 5 == 0) {
                        placeAttachedBud(level, frame, sideSign < 0 ? across.getOpposite() : across, random);
                    }
                }
            }
        }

        // The curved crown forms a genuine arch rather than a rectangular slit.
        for (int angleStep = 0; angleStep <= 18; angleStep++) {
            double angle = Math.PI * angleStep / 18.0;
            int side = (int) Math.round(Math.cos(angle) * 11.0);
            int dy = ENTRANCE_ARCH_SPRING + (int) Math.round(Math.sin(angle) * ENTRANCE_ARCH_HEIGHT);
            for (int thickness = -1; thickness <= 1; thickness++) {
                BlockPos frame = base.relative(forward, frameDistance + thickness).relative(across, side).above(dy);
                placeCrystalIfReplaceable(level, frame);
            }
        }
    }

    private static void buildArenaFloor(WorldGenLevel level, BlockPos base, Entrance entrance) {
        int floorY = base.getY();
        Direction forward = entrance.direction;
        Direction across = forward.getClockWise();
        for (int side = -9; side <= 9; side++) {
            for (int depth = -7; depth <= 7; depth++) {
                double metric = (side * side) / 100.0 + (depth * depth) / 64.0;
                if (metric > 1.0) continue;
                BlockPos floor = new BlockPos(base.getX(), floorY, base.getZ())
                        .relative(forward, depth).relative(across, side);
                BlockState state = metric > 0.78
                        ? AbyssContent.ABYSSAL_TILES.defaultBlockState()
                        : AbyssContent.POLISHED_ABYSSAL_STONE.defaultBlockState();
                if (isCarveable(level.getBlockState(floor)) || isNaturalRock(level.getBlockState(floor))) {
                    level.setBlock(floor, state, 2);
                }
            }
        }
    }

    private static void addInteriorCrystals(WorldGenLevel level, BlockPos base, Entrance entrance, RandomSource random) {
        Direction forward = entrance.direction;
        Direction across = forward.getClockWise();
        for (int i = 0; i < 24; i++) {
            int side = random.nextBoolean() ? -11 : 11;
            int depth = random.nextInt(15) - 7;
            int y = 4 + random.nextInt(17);
            BlockPos support = base.relative(across, side).relative(forward, depth).above(y);
            Direction towardRoom = side < 0 ? across : across.getOpposite();
            placeAttachedBud(level, support, towardRoom, random);
        }
        attachInteriorCluster(level, base.above(23).relative(forward.getOpposite(), 2), Direction.DOWN, random);
    }

    private static void addExteriorBudding(WorldGenLevel level, BlockPos base, RandomSource random) {
        for (int attempt = 0; attempt < 420; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            int radius = 10 + random.nextInt(12);
            int y = random.nextInt(SHELL_HEIGHT + 1);
            BlockPos support = base.offset((int) Math.round(Math.cos(angle) * radius), y,
                    (int) Math.round(Math.sin(angle) * radius));
            if (isCrystalBlock(level.getBlockState(support))) {
                Direction face = HORIZONTAL[random.nextInt(HORIZONTAL.length)];
                placeAttachedBud(level, support, face, random);
            }
        }
    }

    private static void attachInteriorCluster(WorldGenLevel level, BlockPos support, Direction towardRoom,
                                              RandomSource random) {
        placeAttachedBud(level, support, towardRoom, random);
    }

    private static void placeAttachedBud(WorldGenLevel level, BlockPos support, Direction face,
                                         RandomSource random) {
        if (!isCrystalBlock(level.getBlockState(support))) return;
        BlockPos target = support.relative(face);
        if (!AbyssWorldgen.isAbyssY(target.getY()) || !level.getBlockState(target).isAir()) return;

        float choice = random.nextFloat();
        BlockState cluster;
        if (choice < 0.18F) cluster = AbyssContent.RED_CRYSTAL_CLUSTER.defaultBlockState();
        else if (choice < 0.56F) cluster = AbyssContent.LARGE_RED_CRYSTAL_BUD.defaultBlockState();
        else if (choice < 0.82F) cluster = AbyssContent.MEDIUM_RED_CRYSTAL_BUD.defaultBlockState();
        else cluster = AbyssContent.SMALL_RED_CRYSTAL_BUD.defaultBlockState();
        level.setBlock(support, AbyssContent.BUDDING_RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
        level.setBlock(target, cluster.setValue(AmethystClusterBlock.FACING, face), 2);
    }

    private static void placeCrystalIfReplaceable(WorldGenLevel level, BlockPos pos) {
        if (AbyssWorldgen.isAbyssY(pos.getY())
                && (isNaturalOrAir(level.getBlockState(pos)) || isCrystalBlock(level.getBlockState(pos)))) {
            level.setBlock(pos, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
        }
    }

    private static void carveBlock(WorldGenLevel level, BlockPos pos) {
        if (AbyssWorldgen.isAbyssY(pos.getY()) && isCarveable(level.getBlockState(pos))) {
            level.setBlock(pos, Blocks.CAVE_AIR.defaultBlockState(), 2);
        }
    }

    private static Entrance findCaveEntrance(WorldGenLevel level, BlockPos base) {
        Direction[] directions = {Direction.SOUTH, Direction.EAST, Direction.NORTH, Direction.WEST};
        Entrance best = null;
        for (Direction direction : directions) {
            Direction across = direction.getClockWise();
            for (int distance = 17; distance <= 23; distance++) {
                BlockPos sample = base.relative(direction, distance).above(10);
                int open = 0;
                for (int side = -4; side <= 4; side++) {
                    for (int dy = -6; dy <= 6; dy++) {
                        if (level.getBlockState(sample.relative(across, side).above(dy)).isAir()) open++;
                    }
                }
                if (open >= 45 && (best == null || distance < best.distance)) {
                    best = new Entrance(direction, distance);
                    break;
                }
            }
        }
        return best != null ? best : new Entrance(Direction.SOUTH, 22);
    }

    private static boolean isCarveable(BlockState state) {
        return isNaturalOrAir(state) || isCrystalBlock(state)
                || state.is(AbyssContent.RED_CRYSTAL_CLUSTER)
                || state.is(AbyssContent.LARGE_RED_CRYSTAL_BUD)
                || state.is(AbyssContent.MEDIUM_RED_CRYSTAL_BUD)
                || state.is(AbyssContent.SMALL_RED_CRYSTAL_BUD);
    }

    private static boolean isCrystalBlock(BlockState state) {
        return state.is(AbyssContent.RED_CRYSTAL_BLOCK)
                || state.is(AbyssContent.BUDDING_RED_CRYSTAL_BLOCK);
    }

    private static boolean isNaturalRock(BlockState state) {
        return state.is(Blocks.STONE)
                || state.is(Blocks.DEEPSLATE)
                || state.is(Blocks.COBBLED_DEEPSLATE)
                || state.is(Blocks.TUFF)
                || state.is(Blocks.BASALT)
                || state.is(Blocks.BLACKSTONE)
                || state.is(AbyssContent.ABYSSAL_STONE)
                || state.is(AbyssContent.CRACKED_ABYSSAL_STONE)
                || state.is(AbyssContent.POLISHED_ABYSSAL_STONE)
                || state.is(AbyssContent.ABYSSAL_TILES)
                || state.is(AbyssContent.AMETHYST_CORRUPTED_STONE)
                || state.is(AbyssContent.ABYSSAL_PILLAR);
    }

    private static boolean isNaturalOrAir(BlockState state) {
        return state.isAir() || isNaturalRock(state);
    }

    private static double octagonalMetric(double x, double z) {
        double ax = Math.abs(x);
        double az = Math.abs(z);
        return Math.max(ax, az) + Math.min(ax, az) * 0.38;
    }

    private static double angularDistance(double a, double b) {
        double difference = Math.abs(a - b) % (Math.PI * 2.0);
        return Math.min(difference, Math.PI * 2.0 - difference);
    }

    private record GroundAnchor(int x, int y, int z) {}
    private record Entrance(Direction direction, int distance) {}
}
