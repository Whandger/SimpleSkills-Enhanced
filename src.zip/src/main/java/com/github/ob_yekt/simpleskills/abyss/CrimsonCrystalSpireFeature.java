package com.github.ob_yekt.simpleskills.abyss;

import com.github.ob_yekt.simpleskills.Simpleskills;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;

/** Generates large red-crystal teeth attached to cavern floors, ceilings, or side walls. */
public record CrimsonCrystalSpireFeature(
        String mode,
        int minLength,
        int maxLength,
        int minRadius,
        int maxRadius,
        int clusterCount
) implements Feature {
    private static final Direction[] HORIZONTAL = {
            Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST
    };

    public static final MapCodec<CrimsonCrystalSpireFeature> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.STRING.fieldOf("mode").forGetter(CrimsonCrystalSpireFeature::mode),
            Codec.intRange(8, 30).fieldOf("min_length").forGetter(CrimsonCrystalSpireFeature::minLength),
            Codec.intRange(8, 30).fieldOf("max_length").forGetter(CrimsonCrystalSpireFeature::maxLength),
            Codec.intRange(1, 5).fieldOf("min_radius").forGetter(CrimsonCrystalSpireFeature::minRadius),
            Codec.intRange(1, 5).fieldOf("max_radius").forGetter(CrimsonCrystalSpireFeature::maxRadius),
            Codec.intRange(0, 10).fieldOf("cluster_count").forGetter(CrimsonCrystalSpireFeature::clusterCount)
    ).apply(instance, CrimsonCrystalSpireFeature::new));

    public static void registerType() {
        Registry.register(BuiltInRegistries.FEATURE_TYPE,
                Identifier.fromNamespaceAndPath(Simpleskills.MOD_ID, "crimson_crystal_spire"), CODEC);
    }

    @Override
    public MapCodec<? extends Feature> codec() {
        return CODEC;
    }

    @Override
    public boolean place(WorldGenLevel level, ChunkGenerator chunkGenerator, RandomSource random, BlockPos origin) {
        if (minLength > maxLength || minRadius > maxRadius
                || !AbyssWorldgen.isOverworld(level)
                || !AbyssWorldgen.isAbyssY(origin.getY())
                || !AbyssWorldgen.isCrimsonCrystalBiome(origin.getX(), origin.getZ(), level.getSeed())) {
            return false;
        }

        return switch (mode) {
            case "floor" -> {
                BlockPos anchor = findVerticalAnchor(level, origin, false);
                yield anchor != null && growVertical(level, anchor, Direction.UP, random);
            }
            case "ceiling" -> {
                BlockPos anchor = findVerticalAnchor(level, origin, true);
                yield anchor != null && growVertical(level, anchor, Direction.DOWN, random);
            }
            case "wall" -> {
                WallAnchor anchor = findWallAnchor(level, origin, random);
                yield anchor != null && growHorizontal(level, anchor, random);
            }
            default -> false;
        };
    }

    private BlockPos findVerticalAnchor(WorldGenLevel level, BlockPos origin, boolean ceiling) {
        for (int distance = 0; distance <= 26; distance++) {
            int[] offsets = distance == 0 ? new int[]{0} : new int[]{distance, -distance};
            for (int offset : offsets) {
                BlockPos candidate = origin.offset(0, offset, 0);
                BlockPos support = ceiling ? candidate.above() : candidate.below();
                Direction supportFace = ceiling ? Direction.DOWN : Direction.UP;
                if (candidate.getY() > AbyssWorldgen.MIN_Y && candidate.getY() < AbyssWorldgen.MAX_Y
                        && level.getBlockState(candidate).isAir()
                        && isNaturalRock(level.getBlockState(support))
                        && level.getBlockState(support).isFaceSturdy(level, support, supportFace)) {
                    return candidate;
                }
            }
        }
        return null;
    }

    private WallAnchor findWallAnchor(WorldGenLevel level, BlockPos origin, RandomSource random) {
        int start = random.nextInt(HORIZONTAL.length);
        for (int directionIndex = 0; directionIndex < HORIZONTAL.length; directionIndex++) {
            Direction direction = HORIZONTAL[(start + directionIndex) % HORIZONTAL.length];
            for (int distance = 0; distance <= 12; distance++) {
                int[] verticalOffsets = distance == 0 ? new int[]{0} : new int[]{0, 2, -2, 4, -4};
                for (int dy : verticalOffsets) {
                    BlockPos candidate = origin.relative(direction, distance).above(dy);
                    BlockPos support = candidate.relative(direction.getOpposite());
                    BlockState supportState = level.getBlockState(support);
                    if (!AbyssWorldgen.isAbyssY(candidate.getY()) || !level.getBlockState(candidate).isAir()
                            || !isNaturalRock(supportState)
                            || !supportState.isFaceSturdy(level, support, direction)) {
                        continue;
                    }
                    boolean open = true;
                    for (int step = 1; step <= 3; step++) {
                        if (!level.getBlockState(candidate.relative(direction, step)).isAir()) {
                            open = false;
                            break;
                        }
                    }
                    if (open) return new WallAnchor(candidate, direction);
                }
            }
        }
        return null;
    }

    private boolean growVertical(WorldGenLevel level, BlockPos anchor, Direction direction, RandomSource random) {
        int length = between(random, minLength, maxLength);
        double baseRadius = between(random, minRadius, maxRadius);
        double radiusX = baseRadius * (0.88 + random.nextDouble() * 0.22);
        double radiusZ = baseRadius * (0.88 + random.nextDouble() * 0.22);
        int driftX = 0;
        int driftZ = 0;
        boolean placed = false;

        for (int layer = 0; layer < length; layer++) {
            BlockPos center = anchor.relative(direction, layer).offset(driftX, 0, driftZ);
            if (!AbyssWorldgen.isAbyssY(center.getY())) break;
            double progress = layer / (double) Math.max(1, length - 1);
            double taper = 1.0 - 0.74 * progress;
            double layerRadiusX = Math.max(0.85, radiusX * taper + (random.nextDouble() - 0.5) * 0.45);
            double layerRadiusZ = Math.max(0.85, radiusZ * taper + (random.nextDouble() - 0.5) * 0.45);
            if (layer > 2 && layer % 4 == 0 && random.nextFloat() < 0.38F) {
                driftX += random.nextInt(3) - 1;
                driftZ += random.nextInt(3) - 1;
            }

            int boundX = (int) Math.ceil(layerRadiusX);
            int boundZ = (int) Math.ceil(layerRadiusZ);
            for (int dx = -boundX; dx <= boundX; dx++) {
                for (int dz = -boundZ; dz <= boundZ; dz++) {
                    double ellipse = dx * dx / (layerRadiusX * layerRadiusX)
                            + dz * dz / (layerRadiusZ * layerRadiusZ);
                    if (ellipse > 1.0 + (random.nextDouble() - 0.5) * 0.16) continue;
                    placed |= placeCrystal(level, center.offset(dx, 0, dz), random);
                }
            }

            if (layer > 1 && layer % 2 == 0) {
                for (Direction face : HORIZONTAL) {
                    if (random.nextFloat() < 0.45F) {
                        placeAttachedBud(level, center, face, random);
                    }
                }
            }
        }
        placeRandomClusters(level, anchor, direction, length, baseRadius, random);
        return placed;
    }

    private boolean growHorizontal(WorldGenLevel level, WallAnchor anchor, RandomSource random) {
        int length = Math.min(16, between(random, minLength, maxLength));
        double baseRadius = between(random, minRadius, maxRadius);
        Direction along = anchor.direction;
        Direction across = along.getClockWise();
        double verticalRadius = baseRadius * 0.92;
        double crossRadius = baseRadius * 0.86;
        int driftY = 0;
        int driftAcross = 0;
        boolean placed = false;

        for (int layer = 0; layer < length; layer++) {
            BlockPos center = anchor.pos.relative(along, layer).above(driftY).relative(across, driftAcross);
            if (!AbyssWorldgen.isAbyssY(center.getY())) break;
            double progress = layer / (double) Math.max(1, length - 1);
            double taper = 1.0 - 0.72 * progress;
            double ry = Math.max(0.9, verticalRadius * taper + (random.nextDouble() - 0.5) * 0.35);
            double rc = Math.max(0.9, crossRadius * taper + (random.nextDouble() - 0.5) * 0.35);
            if (layer > 1 && layer % 3 == 0 && random.nextFloat() < 0.32F) {
                driftY += random.nextInt(3) - 1;
                driftAcross += random.nextInt(3) - 1;
            }
            int yBound = (int) Math.ceil(ry);
            int crossBound = (int) Math.ceil(rc);
            for (int dy = -yBound; dy <= yBound; dy++) {
                for (int dc = -crossBound; dc <= crossBound; dc++) {
                    double ellipse = dy * dy / (ry * ry) + dc * dc / (rc * rc);
                    if (ellipse > 1.0 + (random.nextDouble() - 0.5) * 0.15) continue;
                    placed |= placeCrystal(level, center.above(dy).relative(across, dc), random);
                }
            }
            if (layer > 1 && layer % 2 == 0 && random.nextFloat() < 0.8F) {
                placeAttachedBud(level, center, Direction.UP, random);
                placeAttachedBud(level, center, Direction.DOWN, random);
            }
        }
        placeRandomClusters(level, anchor.pos, along, length, baseRadius, random);
        return placed;
    }

    private void placeRandomClusters(WorldGenLevel level, BlockPos anchor, Direction axis, int length,
                                     double radius, RandomSource random) {
        int attempts = Math.max(clusterCount * 2, 1);
        for (int attempt = 0; attempt < attempts; attempt++) {
            int layer = random.nextInt(Math.max(1, length));
            BlockPos center = anchor.relative(axis, layer);
            Direction face = HORIZONTAL[random.nextInt(HORIZONTAL.length)];
            placeAttachedBud(level, center, face, random);
        }
    }

    private static boolean placeCrystal(WorldGenLevel level, BlockPos pos, RandomSource random) {
        if (!AbyssWorldgen.isAbyssY(pos.getY())
                || !AbyssWorldgen.isCrimsonCrystalBiome(pos.getX(), pos.getZ(), level.getSeed())
                || !level.getBlockState(pos).isAir()) {
            return false;
        }
        // Budding blocks are created only by placeAttachedBud(), where a visible crystal
        // is placed against one of their faces in the same operation. The solid mass itself
        // must not contain hidden budding blocks with no crystal growing out of them.
        level.setBlock(pos, AbyssContent.RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
        return true;
    }

    private static void placeAttachedBud(WorldGenLevel level, BlockPos center, Direction face, RandomSource random) {
        BlockPos support = center;
        BlockPos target = support.relative(face);
        if (!AbyssWorldgen.isAbyssY(target.getY())
                || !AbyssWorldgen.isCrimsonCrystalBiome(target.getX(), target.getZ(), level.getSeed())
                || !level.getBlockState(target).isAir()
                || !isCrystalBlock(level.getBlockState(support))) return;

        BlockState cluster;
        float choice = random.nextFloat();
        if (choice < 0.16F) cluster = AbyssContent.RED_CRYSTAL_CLUSTER.defaultBlockState();
        else if (choice < 0.43F) cluster = AbyssContent.LARGE_RED_CRYSTAL_BUD.defaultBlockState();
        else if (choice < 0.73F) cluster = AbyssContent.MEDIUM_RED_CRYSTAL_BUD.defaultBlockState();
        else cluster = AbyssContent.SMALL_RED_CRYSTAL_BUD.defaultBlockState();
        // Turn this support into a budding block only when the outward-facing crystal
        // can be placed successfully. Thus every generated budding block has a visible bud.
        level.setBlock(support, AbyssContent.BUDDING_RED_CRYSTAL_BLOCK.defaultBlockState(), 2);
        level.setBlock(target, cluster.setValue(AmethystClusterBlock.FACING, face), 2);
    }

    private static boolean isCrystalBlock(BlockState state) {
        return state.is(AbyssContent.RED_CRYSTAL_BLOCK)
                || state.is(AbyssContent.BUDDING_RED_CRYSTAL_BLOCK);
    }

    private static boolean isNaturalRock(BlockState state) {
        return state.is(AbyssContent.ABYSSAL_STONE)
                || state.is(AbyssContent.CRACKED_ABYSSAL_STONE)
                || state.is(AbyssContent.AMETHYST_CORRUPTED_STONE)
                || state.is(AbyssContent.ABYSSAL_PILLAR)
                || state.is(Blocks.STONE)
                || state.is(Blocks.DEEPSLATE)
                || state.is(Blocks.COBBLED_DEEPSLATE)
                || state.is(Blocks.TUFF)
                || state.is(Blocks.BASALT)
                || state.is(Blocks.BLACKSTONE);
    }

    private static int between(RandomSource random, int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    private record WallAnchor(BlockPos pos, Direction direction) {}
}
