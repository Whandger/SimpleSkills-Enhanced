package com.github.ob_yekt.simpleskills.managers;

import com.github.ob_yekt.simpleskills.Simpleskills;
import com.github.ob_yekt.simpleskills.Skills;
import com.github.ob_yekt.simpleskills.fishing.FishingConfig;
import com.github.ob_yekt.simpleskills.enchanting.EnchantmentLimits;
import com.github.ob_yekt.simpleskills.requirements.SkillRequirement;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

import static net.fabricmc.loader.impl.util.StringUtil.capitalize;

/**
 * Manages all JSON-based configurations for the SimpleSkills mod, including base XP, block mappings, requirements, and prayer sacrifices.
 */
public class ConfigManager {
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("simpleskills");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<Skills, Integer> BASE_XP_MAP = new HashMap<>();
    private static final Map<String, Skills> BLOCK_SKILL_MAP = new HashMap<>();
    private static final Map<String, Integer> BLOCK_XP_MAP = new HashMap<>();
    private static final Map<String, SkillRequirement> TOOL_REQUIREMENTS = new HashMap<>();
    private static final Map<String, SkillRequirement> ARMOR_REQUIREMENTS = new HashMap<>();
    private static final Map<String, SkillRequirement> WEAPON_REQUIREMENTS = new HashMap<>();
    private static final Map<String, List<SkillRequirement>> ENCHANTMENT_REQUIREMENTS = new HashMap<>();
    private static int enchantmentXpPerLevelSquared = 100;
    private static final Map<String, Integer> COOKING_XP_MAP = new HashMap<>();
    private static final Map<String, Float> COOKING_MULTIPLIER_MAP = new HashMap<>();
    private static final Map<String, Integer> CRAFTING_XP_MAP = new HashMap<>();
    private static final Map<String, Integer> SMELTING_CRAFTING_XP_MAP = new HashMap<>();
    private static JsonObject craftingMultipliersConfig = new JsonObject();
    private static final Set<String> CRAFTING_RECOVERY_BLACKLIST = new HashSet<>();
    private static final Map<String, Integer> ALCHEMY_XP_MAP = new HashMap<>();
    private static final Map<String, Float> ALCHEMY_MULTIPLIER_MAP = new HashMap<>();
    private static final Map<String, Integer> AGILITY_XP_MAP = new HashMap<>();
    private static final Map<String, Float> SMITHING_XP_MAP = new HashMap<>();
    private static final Map<String, Integer> FARMING_ACTION_XP_MAP = new HashMap<>();
    private static final Map<String, CropConfig> CROP_CONFIGS = new HashMap<>();
    private static final Map<String, Float> SMITHING_MULTIPLIER_MAP = new HashMap<>();
    private static final Map<String, Integer> FISHING_XP_MAP = new HashMap<>();
    private static final Map<String, Identifier> FISHING_LOOT_TABLES = new HashMap<>();
    private static JsonObject featureConfig = new JsonObject();
    private static JsonObject combatConfig = new JsonObject();

    /**
     * Initializes all configurations.
     */
    public static void initialize() {
        try {
            Files.createDirectories(CONFIG_DIR);
            loadBaseXPConfig();
            loadFeatureConfig();
            loadAgilityXPConfig();
            loadBlockMappings();
            loadToolRequirements();
            loadArmorRequirements();
            loadWeaponRequirements();
            loadEnchantmentRequirements();
            EnchantmentLimits.reload();
            loadCookingXPConfig();
            loadCookingMultipliersConfig();
            loadCraftingXPConfig();
            loadCraftingMultipliersConfig();
            loadCraftingRecoveryBlacklist();
            loadSmeltingCraftingXPConfig();
            loadAlchemyXPConfig();
            loadAlchemyMultiplierConfig();
            loadSmithingXPConfig();
            loadSmithingMultiplierConfig();
            loadFishingXPConfig();
            loadFishingLootConfig();
            loadFarmingXPConfig();
            loadCombatConfig();
            FishingConfig.reload();
            Simpleskills.LOGGER.info("All configurations initialized successfully.");
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error initializing configurations: {}", e.getMessage());
        }
    }

    /**
     * Loads the base XP configuration from base_xp.json.
     */
    private static void loadBaseXPConfig() {
        Path filePath = CONFIG_DIR.resolve("base_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultBaseXPConfig());
            for (Skills skill : Skills.values()) {
                String skillId = skill.getId();
                if (json.has(skillId)) {
                    int xp = json.get(skillId).getAsInt();
                    if (xp >= 0) {
                        BASE_XP_MAP.put(skill, xp);
                    } else {
                        Simpleskills.LOGGER.warn("Invalid XP value for skill {} in base_xp.json, using default", skillId);
                    }
                } else {
                    Simpleskills.LOGGER.warn("Skill {} missing in base_xp.json, using default XP", skillId);
                }
            }
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in base_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading base_xp.json: {}", e.getMessage());
        }
    }

    /**
     * Loads the feature configuration from config.json.
     */
    private static void loadFeatureConfig() {
        Path filePath = CONFIG_DIR.resolve("config.json");
        try {
            JsonObject defaultConfig = getDefaultFeatureConfig();
            JsonObject loadedConfig = loadJsonFile(filePath, defaultConfig);
            // Merge defaults into loaded config for any missing keys
            for (Map.Entry<String, JsonElement> entry : defaultConfig.entrySet()) {
                if (!loadedConfig.has(entry.getKey())) {
                    loadedConfig.add(entry.getKey(), entry.getValue());
                } else if (entry.getValue().isJsonObject()) {
                    JsonObject defaults = entry.getValue().getAsJsonObject();
                    JsonElement configured = loadedConfig.get(entry.getKey());
                    JsonObject section = configured != null && configured.isJsonObject()
                            ? configured.getAsJsonObject() : new JsonObject();
                    for (Map.Entry<String, JsonElement> setting : defaults.entrySet()) {
                        if (!section.has(setting.getKey())) section.add(setting.getKey(), setting.getValue());
                    }
                    loadedConfig.add(entry.getKey(), section);
                }
            }
            featureConfig = loadedConfig;
            // Save the merged config back to disk
            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                GSON.toJson(loadedConfig, writer);
            }
            Simpleskills.LOGGER.info("Loaded and merged config.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in config.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading config.json: {}", e.getMessage());
        }
    }

    /**
     * Default base XP configuration.
     */
    private static JsonObject getDefaultBaseXPConfig() {
        JsonObject json = new JsonObject();
        for (Skills skill : Skills.values()) {
            json.addProperty(skill.getId(), 100);
        }
        return json;
    }

    /**
     * Provides the default feature configuration for config.json.
     */
    private static JsonObject getDefaultFeatureConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("xp_notifications_enabled", true);
        json.addProperty("xp_notification_threshold", 10);
        json.addProperty("standard_xp_multiplier", 1.0);
        json.addProperty("ironman_xp_multiplier", 0.5);
        json.addProperty("ironman_health_reduction", -6.0);
        json.addProperty("broadcast_ironman_death", true);
        json.addProperty("force_ironman_mode", false);
        json.addProperty("level_up_effects_enabled", true);
        json.addProperty("level_up_notifications_enabled", true);
        json.addProperty("item_requirements_in_tooltips_enabled", true);
        json.addProperty("crafting_lore_in_tooltips_enabled", true);
        json.addProperty("custom_fishing_loot_enabled", true);
        json.addProperty("fishing_speed_bonus_enabled", true);
        JsonObject agility = new JsonObject();
        agility.addProperty("dash_unlocked_at", 15);
        agility.addProperty("dash_cooldown_ticks_base", 100);
        agility.addProperty("dash_cooldown_reduction_per_level", 0.5);
        agility.addProperty("dash_impulse", 1.2);
        agility.addProperty("dash_vertical_impulse", 0.35);
        agility.addProperty("dash_iframe_ticks", 4);
        agility.addProperty("dash_exhaustion", 1.0);
        agility.addProperty("double_jump_unlocked_at", 10);
        agility.addProperty("double_jump_vertical_velocity", 0.9);
        agility.addProperty("double_jump_exhaustion", 1.0);
        json.add("agility", agility);
        // Fishing minigame (see fishing/FishingConfig.java for the meaning of every option)
        FishingConfig.addDefaults(json);
        return json;
    }

    /**
     * Get force_ironman_mode setting.
     */
    public static boolean isForceIronmanModeEnabled() {
        return featureConfig.get("force_ironman_mode").getAsBoolean();
    }

    /**
     * Loads block mappings from block_mappings.json.
     */
    private static void loadBlockMappings() {
        Path filePath = CONFIG_DIR.resolve("block_mappings.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultBlockMappings());
            var mappings = json.getAsJsonArray("block_mappings");
            BLOCK_SKILL_MAP.clear();
            BLOCK_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String block = mapping.get("block").getAsString();
                String skillId = mapping.get("skill").getAsString();
                int xp = mapping.get("xp").getAsInt();

                try {
                    Skills skill = Skills.valueOf(skillId.toUpperCase());
                    if (xp < 0) {
                        Simpleskills.LOGGER.warn("Invalid XP value {} for block {} in block_mappings.json, skipping", xp, block);
                        continue;
                    }
                    // Handle pattern-based blocks (e.g., block.minecraft.*_planks)
                    if (block.contains("*")) {
                        String regex = block.replace("*", ".*");
                        for (var blockEntry : BuiltInRegistries.BLOCK.entrySet()) {
                            String translationKey = blockEntry.getValue().getDescriptionId();
                            if (translationKey.matches(regex)) {
                                BLOCK_SKILL_MAP.put(translationKey, skill);
                                BLOCK_XP_MAP.put(translationKey, xp);
                            }
                        }
                    } else {
                        BLOCK_SKILL_MAP.put(block, skill);
                        BLOCK_XP_MAP.put(block, xp);
                    }
                } catch (IllegalArgumentException e) {
                    Simpleskills.LOGGER.warn("Invalid skill {} for block {} in block_mappings.json, skipping", skillId, block);
                }
            }
            // Built-in Rune ores are always Mining blocks. Add them after loading the user file
            // so existing installations receive the new mappings without overwriting overrides.
            BLOCK_SKILL_MAP.putIfAbsent("block.simpleskills.rune_ore", Skills.MINING);
            BLOCK_XP_MAP.putIfAbsent("block.simpleskills.rune_ore", 900);
            BLOCK_SKILL_MAP.putIfAbsent("block.simpleskills.deepslate_rune_ore", Skills.MINING);
            BLOCK_XP_MAP.putIfAbsent("block.simpleskills.deepslate_rune_ore", 1100);

            // Apply new Excavating defaults to existing installations without overwriting
            // any block values explicitly configured by the server owner.
            Map<String, Integer> excavatingDefaults = Map.ofEntries(
                    Map.entry("block.minecraft.dirt", 100),
                    Map.entry("block.minecraft.grass_block", 100),
                    Map.entry("block.minecraft.coarse_dirt", 100),
                    Map.entry("block.minecraft.rooted_dirt", 100),
                    Map.entry("block.minecraft.podzol", 100),
                    Map.entry("block.minecraft.mycelium", 100),
                    Map.entry("block.minecraft.sand", 150),
                    Map.entry("block.minecraft.red_sand", 150),
                    Map.entry("block.minecraft.gravel", 150),
                    Map.entry("block.minecraft.clay", 250),
                    Map.entry("block.minecraft.soul_sand", 400),
                    Map.entry("block.minecraft.soul_soil", 400)
            );
            excavatingDefaults.forEach((block, xp) -> {
                BLOCK_SKILL_MAP.putIfAbsent(block, Skills.EXCAVATING);
                BLOCK_XP_MAP.putIfAbsent(block, xp);
            });

            Simpleskills.LOGGER.info("Loaded {} block mappings.", BLOCK_SKILL_MAP.size());
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in block_mappings.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading block_mappings.json: {}", e.getMessage());
        }
    }


    /**
     * Loads agility XP mappings from agility_xp.json.
     */
    private static void loadAgilityXPConfig() {
        Path filePath = CONFIG_DIR.resolve("agility_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultAgilityXPConfig());
            var mappings = json.getAsJsonArray("agility_mappings");
            AGILITY_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String action = mapping.get("action").getAsString();
                int xp = mapping.get("xp").getAsInt();

                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Invalid XP value {} for action {} in agility_xp.json, skipping", xp, action);
                    continue;
                }
                AGILITY_XP_MAP.put(action, xp);
            }
            Simpleskills.LOGGER.info("Loaded agility_xp.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in agility_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading agility_xp.json: {}", e.getMessage());
        }
    }

    private static void loadToolRequirements() {
        Path filePath = CONFIG_DIR.resolve("tool_requirements.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultToolRequirements());
            for (var entry : json.entrySet()) {
                String toolId = entry.getKey();
                JsonObject data = entry.getValue().getAsJsonObject();
                String skillId = data.get("skill").getAsString();
                int level = data.get("level").getAsInt();
                try {
                    Skills skill = Skills.valueOf(skillId.toUpperCase());
                    int prestige = data.has("prestige") ? data.get("prestige").getAsInt() : 0;
                    if (level >= 0 && prestige >= 0) {
                        TOOL_REQUIREMENTS.put(toolId, new SkillRequirement(skill, level, null, prestige));
                    } else {
                        Simpleskills.LOGGER.warn("Invalid level for tool {} in tool_requirements.json", toolId);
                    }
                } catch (IllegalArgumentException e) {
                    Simpleskills.LOGGER.warn("Invalid skill {} for tool {} in tool_requirements.json", skillId, toolId);
                }
            }
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in tool_requirements.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading tool_requirements.json: {}", e.getMessage());
        }
    }

    private static void loadArmorRequirements() {
        Path filePath = CONFIG_DIR.resolve("armor_requirements.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultArmorRequirements());
            for (var entry : json.entrySet()) {
                String armorId = entry.getKey();
                JsonObject data = entry.getValue().getAsJsonObject();
                String skillId = data.get("skill").getAsString();
                int level = data.get("level").getAsInt();
                try {
                    Skills skill = Skills.valueOf(skillId.toUpperCase());
                    int prestige = data.has("prestige") ? data.get("prestige").getAsInt() : 0;
                    if (level >= 0 && prestige >= 0) {
                        ARMOR_REQUIREMENTS.put(armorId, new SkillRequirement(skill, level, null, prestige));
                    } else {
                        Simpleskills.LOGGER.warn("Invalid level for armor {} in armor_requirements.json", armorId);
                    }
                } catch (IllegalArgumentException e) {
                    Simpleskills.LOGGER.warn("Invalid skill {} for armor {} in armor_requirements.json", skillId, armorId);
                }
            }
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in armor_requirements.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading armor_requirements.json: {}", e.getMessage());
        }
    }

    private static void loadWeaponRequirements() {
        Path filePath = CONFIG_DIR.resolve("weapon_requirements.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultWeaponRequirements());
            for (var entry : json.entrySet()) {
                String weaponId = entry.getKey();
                JsonObject data = entry.getValue().getAsJsonObject();
                String skillId = data.get("skill").getAsString();
                int level = data.get("level").getAsInt();
                try {
                    Skills skill = Skills.valueOf(skillId.toUpperCase());
                    int prestige = data.has("prestige") ? data.get("prestige").getAsInt() : 0;
                    if (level >= 0 && prestige >= 0) {
                        WEAPON_REQUIREMENTS.put(weaponId, new SkillRequirement(skill, level, null, prestige));
                    } else {
                        Simpleskills.LOGGER.warn("Invalid level for weapon {} in weapon_requirements.json", weaponId);
                    }
                } catch (IllegalArgumentException e) {
                    Simpleskills.LOGGER.warn("Invalid skill {} for weapon {} in weapon_requirements.json", skillId, weaponId);
                }
            }
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in weapon_requirements.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading weapon_requirements.json: {}", e.getMessage());
        }
    }

    private static void loadEnchantmentRequirements() {
        Path filePath = CONFIG_DIR.resolve("enchantment_requirements.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultEnchantmentRequirements());
            ENCHANTMENT_REQUIREMENTS.clear();

            // Load XP multiplier
            if (json.has("enchantment_xp_per_level_squared")) {
                enchantmentXpPerLevelSquared = json.get("enchantment_xp_per_level_squared").getAsInt();
            }

            // Load requirements
            if (json.has("requirements")) {
                JsonObject requirements = json.getAsJsonObject("requirements");
                for (var entry : requirements.entrySet()) {
                    String enchantmentId = entry.getKey();
                    JsonArray reqArray = entry.getValue().getAsJsonArray();
                    List<SkillRequirement> reqList = new ArrayList<>();

                    for (JsonElement reqElement : reqArray) {
                        JsonObject reqObj = reqElement.getAsJsonObject();
                        String skillId = reqObj.get("skill").getAsString();
                        int level = reqObj.get("level").getAsInt();
                        int enchLevel = reqObj.get("enchantmentLevel").getAsInt();

                        try {
                            Skills skill = Skills.valueOf(skillId.toUpperCase());
                            if (level >= 0 && enchLevel > 0) {
                                reqList.add(new SkillRequirement(skill, level, enchLevel));
                            }
                        } catch (IllegalArgumentException e) {
                            Simpleskills.LOGGER.warn("Invalid skill {} for enchantment {}", skillId, enchantmentId);
                        }
                    }

                    if (!reqList.isEmpty()) {
                        ENCHANTMENT_REQUIREMENTS.put(enchantmentId, reqList);
                    }
                }
            }
            Simpleskills.LOGGER.info("Loaded enchantment_requirements.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in enchantment_requirements.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading enchantment_requirements.json: {}", e.getMessage());
        }
    }

    private static void loadCombatConfig() {
        Path filePath = CONFIG_DIR.resolve("combat_config.json");
        try {
            combatConfig = loadJsonFile(filePath, getDefaultCombatConfig());
            Simpleskills.LOGGER.info("Loaded combat_config.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in combat_config.json: {}", e.getMessage());
            combatConfig = getDefaultCombatConfig(); // Fallback to defaults
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading combat_config.json: {}", e.getMessage());
            combatConfig = getDefaultCombatConfig(); // Fallback to defaults
        }
    }

    private static JsonObject getDefaultCombatConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("slaying_xp_per_damage", 50.0f);
        json.addProperty("ranged_xp_per_damage", 125.0f);
        json.addProperty("defense_xp_per_damage", 200.0f);
        json.addProperty("slaying_min_damage_threshold", 2.0f);
        json.addProperty("ranged_min_damage_threshold", 2.0f);
        json.addProperty("defense_min_damage_threshold", 2.0f);
        json.addProperty("defense_xp_armor_multiplier_per_piece", 0.25f);
        json.addProperty("defense_shield_xp_multiplier", 0.04f);
        return json;
    }

    public static JsonObject getCombatConfig() {
        if (combatConfig == null) {
            Simpleskills.LOGGER.warn("Combat config is null, returning default config");
            return getDefaultCombatConfig();
        }
        return combatConfig;
    }

    /**
     * Loads cooking multipliers from cooking_multipliers.json.
     */
    private static void loadCookingMultipliersConfig() {
        Path filePath = CONFIG_DIR.resolve("cooking_multipliers.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultCookingMultipliersConfig());
            COOKING_MULTIPLIER_MAP.clear();
            for (var entry : json.entrySet()) {
                String range = entry.getKey();
                float multiplier = entry.getValue().getAsFloat();
                if (multiplier >= 0) {
                    COOKING_MULTIPLIER_MAP.put(range, multiplier);
                } else {
                    Simpleskills.LOGGER.warn("Invalid multiplier {} for range {} in cooking_multipliers.json, skipping", multiplier, range);
                }
            }
            Simpleskills.LOGGER.info("Loaded cooking_multipliers.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in cooking_multipliers.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading cooking_multipliers.json: {}", e.getMessage());
        }
    }

    private static JsonObject getDefaultCookingMultipliersConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("0-24", 0.875f);
        json.addProperty("25-49", 1.0f);
        json.addProperty("50-74", 1.125f);
        json.addProperty("75-98", 1.25f);
        json.addProperty("99-99", 1.5f);
        return json;
    }

    /**
     * Gets the cooking multiplier for a given level.
     */
    public static float getCookingMultiplier(int level) {
        if (level >= 99) {
            return COOKING_MULTIPLIER_MAP.getOrDefault("99-99", 1.5f);
        } else if (level >= 75) {
            return COOKING_MULTIPLIER_MAP.getOrDefault("75-98", 1.25f);
        } else if (level >= 50) {
            return COOKING_MULTIPLIER_MAP.getOrDefault("50-74", 1.125f);
        } else if (level >= 25) {
            return COOKING_MULTIPLIER_MAP.getOrDefault("25-49", 1.0f);
        } else {
            return COOKING_MULTIPLIER_MAP.getOrDefault("0-24", 0.875f);
        }
    }

    /**
     * Loads cooking XP mappings from cooking_xp.json.
     */
    private static void loadCookingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("cooking_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultCookingXPConfig());
            var mappings = json.getAsJsonArray("cooking_mappings");
            COOKING_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String item = mapping.get("item").getAsString();
                int xp = mapping.get("xp").getAsInt();

                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Invalid XP value {} for item {} in cooking_xp.json, skipping", xp, item);
                    continue;
                }
                COOKING_XP_MAP.put(item, xp);
            }
            Simpleskills.LOGGER.info("Loaded cooking_xp.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in cooking_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading cooking_xp.json: {}", e.getMessage());
        }
    }

    /**
     * Loads crafting XP mappings from crafting_xp.json.
     */
    private static void loadCraftingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("crafting_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultCraftingXPConfig());
            var mappings = json.getAsJsonArray("crafting_mappings");
            CRAFTING_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String item = mapping.get("item").getAsString();
                int xp = mapping.get("xp").getAsInt();

                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Invalid XP value {} for item {} in crafting_xp.json, skipping", xp, item);
                    continue;
                }
                CRAFTING_XP_MAP.put(item, xp);
            }
            Simpleskills.LOGGER.info("Loaded crafting_xp.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in crafting_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading crafting_xp.json: {}", e.getMessage());
        }
    }

    /**
     * Default cooking XP configuration.
     */
    private static JsonObject getDefaultCookingXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record CookingMapping(String item, int xp) {
        }
        CookingMapping[] defaults = {
                new CookingMapping("item.minecraft.cooked_porkchop", 185),
                new CookingMapping("item.minecraft.cooked_beef", 185),
                new CookingMapping("item.minecraft.cooked_mutton", 185),
                new CookingMapping("item.minecraft.cooked_chicken", 185),     // Nerfed to compete with baseline meats
                new CookingMapping("item.minecraft.cooked_salmon", 200),     // Higher than meats to reward fishing effort
                new CookingMapping("item.minecraft.cooked_cod", 195),        // Same as salmon
                new CookingMapping("item.minecraft.cooked_rabbit", 285),     // Increased for rarity and biome specificity

                new CookingMapping("item.minecraft.baked_potato", 150),      // Commonly eaten, easy to get
                new CookingMapping("item.minecraft.golden_carrot", 230),     // Slightly higher for gold and carrot effort
                new CookingMapping("item.minecraft.golden_apple", 800),     // Increased for rare apples and gold ingots

                new CookingMapping("item.minecraft.bread", 210),             // Commonly eaten, but need 3 wheat
                new CookingMapping("item.minecraft.cookie", 35),             // Per-cookie, total 280 for 8, for cocoa rarity is just same recipe with bread but one coco and one wheat less
                new CookingMapping("item.minecraft.pumpkin_pie", 400),       // Buffed for complexity and for needing 3 ingredients
                new CookingMapping("item.minecraft.mushroom_stew", 300),     // Boosted for biome-specific mushrooms
                new CookingMapping("item.minecraft.beetroot_soup", 300),     // Never made/eaten
                new CookingMapping("item.minecraft.rabbit_stew", 750),        // Never made/eaten
                new CookingMapping("item.minecraft.suspicious_stew", 250),        // Never made/eaten
                new CookingMapping("block.minecraft.cake", 1250)        // Never made/eaten
        };
        for (CookingMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("item", mapping.item);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }
        json.add("cooking_mappings", mappings);
        return json;
    }


    /**
     * Gets the XP for cooking an item.
     */
    public static int getCookingXP(String itemTranslationKey, Skills skill) {
        return COOKING_XP_MAP.getOrDefault(itemTranslationKey, 0); // Changed from getBaseXP(skill) to 0
    }

    /**
     * Default cooking XP configuration.
     */
    private static JsonObject getDefaultCraftingXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record CraftingMapping(String item, int xp) {
        }
        CraftingMapping[] defaults = {
                // Wood (Base XP: 100 per plank)
                new CraftingMapping("minecraft:wood_shovel", 100),     // 1 plank
                new CraftingMapping("minecraft:wood_spear", 100),     // 1 plank
                new CraftingMapping("minecraft:wood_hoe", 200),        // 2 planks
                new CraftingMapping("minecraft:wood_sword", 200),      // 2 planks
                new CraftingMapping("minecraft:wood_pickaxe", 300),    // 3 planks
                new CraftingMapping("minecraft:wood_axe", 300),        // 3 planks

                // Leather (Base XP: 500 per leather)
                new CraftingMapping("minecraft:leather_helmet", 2500),     // 5 leather
                new CraftingMapping("minecraft:leather_chestplate", 4000), // 8 leather
                new CraftingMapping("minecraft:leather_leggings", 3500),   // 7 leather
                new CraftingMapping("minecraft:leather_boots", 2000),      // 4 leather

                // Stone (Base XP: 150 per cobblestone)
                new CraftingMapping("minecraft:stone_shovel", 150),    // 1 cobblestone
                new CraftingMapping("minecraft:stone_spear", 150),    // 1 cobblestone
                new CraftingMapping("minecraft:stone_hoe", 300),       // 2 cobblestone
                new CraftingMapping("minecraft:stone_sword", 300),     // 2 cobblestone
                new CraftingMapping("minecraft:stone_pickaxe", 450),   // 3 cobblestone
                new CraftingMapping("minecraft:stone_axe", 450),       // 3 cobblestone

                // Gold (Base XP: 800 per gold ingot)
                new CraftingMapping("minecraft:golden_helmet", 4000),      // 5 gold ingots
                new CraftingMapping("minecraft:golden_chestplate", 6400),  // 8 gold ingots
                new CraftingMapping("minecraft:golden_leggings", 5600),    // 7 gold ingots
                new CraftingMapping("minecraft:golden_boots", 3200),       // 4 gold ingots
                new CraftingMapping("minecraft:golden_shovel", 800),       // 1 gold ingot
                new CraftingMapping("minecraft:golden_spear", 800),       // 1 gold ingot
                new CraftingMapping("minecraft:golden_hoe", 1600),         // 2 gold ingots
                new CraftingMapping("minecraft:golden_sword", 1600),       // 2 gold ingots
                new CraftingMapping("minecraft:golden_pickaxe", 2400),     // 3 gold ingots
                new CraftingMapping("minecraft:golden_axe", 2400),         // 3 gold ingots

                // Copper (Base XP: 350 per copper ingot)
                new CraftingMapping("minecraft:copper_helmet", 1750),      // 5 copper ingots
                new CraftingMapping("minecraft:copper_chestplate", 2800),  // 8 copper ingots
                new CraftingMapping("minecraft:copper_leggings", 2450),    // 7 copper ingots
                new CraftingMapping("minecraft:copper_boots", 1400),       // 4 copper ingots
                new CraftingMapping("minecraft:copper_shovel", 350),       // 1 copper ingot
                new CraftingMapping("minecraft:copper_spear", 350),       // 1 copper ingot
                new CraftingMapping("minecraft:copper_hoe", 700),          // 2 copper ingots
                new CraftingMapping("minecraft:copper_sword", 700),        // 2 copper ingots
                new CraftingMapping("minecraft:copper_pickaxe", 1050),     // 3 copper ingots
                new CraftingMapping("minecraft:copper_axe", 1050),         // 3 copper ingots

                // Iron (Base XP: 700 per iron ingot)
                new CraftingMapping("minecraft:iron_helmet", 3500),        // 5 iron ingots
                new CraftingMapping("minecraft:iron_chestplate", 5600),    // 8 iron ingots
                new CraftingMapping("minecraft:iron_leggings", 4900),      // 7 iron ingots
                new CraftingMapping("minecraft:iron_boots", 2800),         // 4 iron ingots
                new CraftingMapping("minecraft:iron_shovel", 700),         // 1 iron ingot
                new CraftingMapping("minecraft:iron_spear", 700),         // 1 iron ingot
                new CraftingMapping("minecraft:iron_hoe", 1400),           // 2 iron ingots
                new CraftingMapping("minecraft:iron_sword", 1400),         // 2 iron ingots
                new CraftingMapping("minecraft:iron_pickaxe", 2100),       // 3 iron ingots
                new CraftingMapping("minecraft:iron_axe", 2100),           // 3 iron ingots

                // Diamond (Base XP: 1500 per diamond)
                new CraftingMapping("minecraft:diamond_helmet", 7500),     // 5 diamonds
                new CraftingMapping("minecraft:diamond_chestplate", 12000), // 8 diamonds
                new CraftingMapping("minecraft:diamond_leggings", 10500),   // 7 diamonds
                new CraftingMapping("minecraft:diamond_boots", 6000),      // 4 diamonds
                new CraftingMapping("minecraft:diamond_shovel", 1500),     // 1 diamond
                new CraftingMapping("minecraft:diamond_spear", 1500),     // 1 diamond
                new CraftingMapping("minecraft:diamond_hoe", 3000),        // 2 diamonds
                new CraftingMapping("minecraft:diamond_sword", 3000),      // 2 diamonds
                new CraftingMapping("minecraft:diamond_pickaxe", 4500),    // 3 diamonds
                new CraftingMapping("minecraft:diamond_axe", 4500),        // 3 diamonds

                // Special Items
                new CraftingMapping("minecraft:shield", 750),
                new CraftingMapping("minecraft:mace", 7500),
                new CraftingMapping("minecraft:crossbow", 1500),
                new CraftingMapping("minecraft:bow", 700)
        };
        for (CraftingMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("item", mapping.item);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }
        json.add("crafting_mappings", mappings);
        return json;
    }

    /**
     * Gets the XP for crafting an item.
     */
    public static int getCraftingXP(String itemTranslationKey, Skills skill) {
        return CRAFTING_XP_MAP.getOrDefault(itemTranslationKey, getBaseXP(skill));
    }

    /**
     * Loads a JSON file or creates it with the default content if it doesn't exist.
     */
    private static JsonObject loadJsonFile(Path filePath, JsonObject defaultJson) throws IOException {
        if (Files.exists(filePath)) {
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath.toFile()))) {
                return GSON.fromJson(reader.lines().collect(Collectors.joining("\n")), JsonObject.class);
            }
        } else {
            Files.createDirectories(filePath.getParent());
            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                GSON.toJson(defaultJson, writer);
            }
            return defaultJson;
        }
    }

    // New method to load crafting multipliers
    private static void loadCraftingMultipliersConfig() {
        Path filePath = CONFIG_DIR.resolve("crafting_multipliers.json");
        try {
            craftingMultipliersConfig = loadJsonFile(filePath, getDefaultCraftingMultipliersConfig());
            Simpleskills.LOGGER.info("Loaded crafting_multipliers.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in crafting_multipliers.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading crafting_multipliers.json: {}", e.getMessage());
        }
    }

    // Default crafting multipliers configuration
    private static JsonObject getDefaultCraftingMultipliersConfig() {
        JsonObject json = new JsonObject();
        JsonObject durability = new JsonObject();
        durability.addProperty("level_99", 1.25f);
        JsonObject recovery = new JsonObject();
        recovery.addProperty("level_99", 0.25f);
        json.add("durability_multipliers", durability);
        json.add("recovery_chances", recovery);
        return json;
    }

    // Durability multiplier, linear per level: 1.0 at level 0, the level_99 value at level 99
    public static float getCraftingDurabilityMultiplier(int level) {
        float max = getCraftingCap("durability_multipliers", "level_99", 1.25f);
        return 1.0f + (max - 1.0f) * clampCraftingLevel(level) / 99.0f;
    }

    // Recovery chance, linear per level: 0 at level 0, the level_99 value at level 99
    public static float getCraftingRecoveryChance(int level) {
        float max = getCraftingCap("recovery_chances", "level_99", 0.25f);
        return max * clampCraftingLevel(level) / 99.0f;
    }

    private static float getCraftingCap(String section, String key, float fallback) {
        JsonObject values = craftingMultipliersConfig.getAsJsonObject(section);
        if (values == null || !values.has(key)) {
            Simpleskills.LOGGER.warn("Missing {}.{} in crafting_multipliers.json, using default {}", section, key, fallback);
            return fallback;
        }
        return values.get(key).getAsFloat();
    }

    private static int clampCraftingLevel(int level) {
        return Math.max(0, Math.min(99, level));
    }

    // New method to load crafting recovery blacklist
    private static void loadCraftingRecoveryBlacklist() {
        Path filePath = CONFIG_DIR.resolve("crafting_recovery_blacklist.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultCraftingRecoveryBlacklist());
            CRAFTING_RECOVERY_BLACKLIST.clear();
            JsonArray blacklist = json.getAsJsonArray("blacklist");
            if (blacklist != null) {
                for (JsonElement element : blacklist) {
                    String itemId = element.getAsString();
                    CRAFTING_RECOVERY_BLACKLIST.add(itemId);
                }
            }
            Simpleskills.LOGGER.info("Loaded crafting_recovery_blacklist.json with {} entries", CRAFTING_RECOVERY_BLACKLIST.size());
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in crafting_recovery_blacklist.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading crafting_recovery_blacklist.json: {}", e.getMessage());
        }
    }

    // Default crafting recovery blacklist configuration
    private static JsonObject getDefaultCraftingRecoveryBlacklist() {
        JsonObject json = new JsonObject();
        JsonArray blacklist = new JsonArray();
        String[] blacklistedItems = {
                "minecraft:gold_nugget",
                "minecraft:gold_ingot",
                "minecraft:gold_block",
                "minecraft:iron_nugget",
                "minecraft:iron_ingot",
                "minecraft:iron_block",
                "minecraft:copper_ingot",
                "minecraft:copper_block",
                "minecraft:copper_nugget",
                "minecraft:waxed_copper_block",
                "minecraft:netherite_ingot",
                "minecraft:netherite_block",
                "minecraft:raw_iron",
                "minecraft:raw_iron_block",
                "minecraft:raw_gold",
                "minecraft:raw_gold_block",
                "minecraft:raw_copper",
                "minecraft:raw_copper_block",
                "minecraft:diamond",
                "minecraft:diamond_block",
                "minecraft:emerald",
                "minecraft:emerald_block",
                "minecraft:coal",
                "minecraft:coal_block",
                "minecraft:lapis_lazuli",
                "minecraft:lapis_lazuli_block",
                "minecraft:resin",
                "minecraft:resin_block",
                "minecraft:redstone",
                "minecraft:redstone_block",
                "minecraft:amethyst_shard",
                "minecraft:amethyst_block",
                "minecraft:wheat",
                "minecraft:hay_block",
                "minecraft:slime_ball",
                "minecraft:slime_block",
                "minecraft:honey_bottle",
                "minecraft:honey_block",
                "minecraft:dried_kelp",
                "minecraft:dried_kelp_block",
                "minecraft:bamboo",
                "minecraft:bamboo_block",
                "minecraft:snowball",
                "minecraft:snow_block",
                "minecraft:clay_ball",
                "minecraft:clay",
                "minecraft:glowstone_dust",
                "minecraft:glowstone",
                "minecraft:bone_meal",
                "minecraft:bone_block",
                "minecraft:wool",
                "minecraft:string",
                "minecraft:quartz_block",
                "minecraft:quartz,",
                "minecraft:nether_wart",
                "minecraft:nether_wart_block",
                "minecraft:ice",
                "minecraft:packed_ice",
                "minecraft:blue_ice",
                // Container / "transform" items: these can carry stored items or other
                // nested data (e.g. DataComponents.CONTAINER, BUNDLE_CONTENTS). Refunding
                // a "recovered" copy of these would duplicate their entire contents, so
                // they are blacklisted by default. The mixins also enforce this in code
                // via isUnsafeForRecovery() regardless of this list, but keeping them here
                // too makes the protection visible/extendable via config.
                "minecraft:shulker_box",
                "minecraft:white_shulker_box",
                "minecraft:orange_shulker_box",
                "minecraft:magenta_shulker_box",
                "minecraft:light_blue_shulker_box",
                "minecraft:yellow_shulker_box",
                "minecraft:lime_shulker_box",
                "minecraft:pink_shulker_box",
                "minecraft:gray_shulker_box",
                "minecraft:light_gray_shulker_box",
                "minecraft:cyan_shulker_box",
                "minecraft:purple_shulker_box",
                "minecraft:blue_shulker_box",
                "minecraft:brown_shulker_box",
                "minecraft:green_shulker_box",
                "minecraft:red_shulker_box",
                "minecraft:black_shulker_box",
                "minecraft:bundle",
                "minecraft:white_bundle",
                "minecraft:orange_bundle",
                "minecraft:magenta_bundle",
                "minecraft:light_blue_bundle",
                "minecraft:yellow_bundle",
                "minecraft:lime_bundle",
                "minecraft:pink_bundle",
                "minecraft:gray_bundle",
                "minecraft:light_gray_bundle",
                "minecraft:cyan_bundle",
                "minecraft:purple_bundle",
                "minecraft:blue_bundle",
                "minecraft:brown_bundle",
                "minecraft:green_bundle",
                "minecraft:red_bundle",
                "minecraft:black_bundle",
                "minecraft:written_book",
                "minecraft:crossbow",
        };
        for (String item : blacklistedItems) {
            blacklist.add(item);
        }
        json.add("blacklist", blacklist);
        return json;
    }

    // Check if a recipe's output item is blacklisted
    public static boolean isRecipeBlacklisted(String itemId) {
        return CRAFTING_RECOVERY_BLACKLIST.contains(itemId);
    }

    /**
     * Loads smelting crafting XP mappings from smelting_crafting_xp.json.
     */
    private static void loadSmeltingCraftingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("smelting_crafting_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultSmeltingCraftingXPConfig());
            var mappings = json.getAsJsonArray("smelting_crafting_mappings");
            SMELTING_CRAFTING_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String item = mapping.get("item").getAsString();
                int xp = mapping.get("xp").getAsInt();

                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Invalid XP value {} for item {} in smelting_crafting_xp.json, skipping", xp, item);
                    continue;
                }
                SMELTING_CRAFTING_XP_MAP.put(item, xp);
            }
            Simpleskills.LOGGER.info("Loaded smelting_crafting_xp.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in smelting_crafting_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading smelting_crafting_xp.json: {}", e.getMessage());
        }
    }

    private static JsonObject getDefaultSmeltingCraftingXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record SmeltingCraftingXP(String item, int xp) {
        }
        SmeltingCraftingXP[] defaults = {
                new SmeltingCraftingXP("item.minecraft.copper_ingot", 125),
                new SmeltingCraftingXP("item.minecraft.copper_nugget", 50),
                new SmeltingCraftingXP("item.minecraft.iron_ingot", 150),
                new SmeltingCraftingXP("item.minecraft.iron_nugget", 62),
                new SmeltingCraftingXP("item.minecraft.gold_ingot", 200),
                new SmeltingCraftingXP("item.minecraft.gold_nugget", 75),
                new SmeltingCraftingXP("item.minecraft.netherite_scrap", 625),
                new SmeltingCraftingXP("item.minecraft.redstone", 80),
                new SmeltingCraftingXP("item.minecraft.coal", 50),
                new SmeltingCraftingXP("item.minecraft.emerald", 225),
                new SmeltingCraftingXP("item.minecraft.lapis_lazuli", 125),
                new SmeltingCraftingXP("item.minecraft.diamond", 250),
                new SmeltingCraftingXP("item.minecraft.quartz", 75)

        };
        for (SmeltingCraftingXP config : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("item", config.item);
            entry.addProperty("xp", config.xp);
            mappings.add(entry);
        }
        json.add("smelting_crafting_mappings", mappings);
        return json;
    }

    /**
     * Gets the smelting crafting XP for an item.
     */
    public static int getSmeltingCraftingXP(String itemKey, Skills skill) {
        return SMELTING_CRAFTING_XP_MAP.getOrDefault(itemKey, 0);
    }

    private static JsonObject getDefaultBlockMappings() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();

        // Block mapping record for simplicity
        record BlockMapping(String block, String skill, int xp) {
        }

        // Wood types for pattern matching
        String[] woodTypes = {
                "oak", "spruce", "birch", "jungle", "acacia", "dark_oak",
                "mangrove", "cherry", "bamboo", "pale_oak", "crimson", "warped"
        };

        // Stone/mineral pattern list removed to allow hardness-based defaults for mining

        List<BlockMapping> defaults = new ArrayList<>();

        // === WOODCUTTING MAPPINGS ===
        for (String wood : woodTypes) {
            if (wood.equals("crimson") || wood.equals("warped")) {
                defaults.add(new BlockMapping("block.minecraft." + wood + "_stem", "WOODCUTTING", 150));
                defaults.add(new BlockMapping("block.minecraft.stripped_" + wood + "_stem", "WOODCUTTING", 150));
            } else {
                defaults.add(new BlockMapping("block.minecraft." + wood + "_log", "WOODCUTTING", 150));
                defaults.add(new BlockMapping("block.minecraft.stripped_" + wood + "_log", "WOODCUTTING", 150));
            }
        }

        defaults.add(new BlockMapping("block.minecraft.bamboo_sapling", "WOODCUTTING", 10));
        defaults.add(new BlockMapping("block.minecraft.bamboo", "WOODCUTTING", 10));

        // === EXCAVATING MAPPINGS ===
        defaults.add(new BlockMapping("block.minecraft.dirt", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.grass_block", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.coarse_dirt", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.rooted_dirt", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.podzol", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.mycelium", "EXCAVATING", 100));
        defaults.add(new BlockMapping("block.minecraft.sand", "EXCAVATING", 150));
        defaults.add(new BlockMapping("block.minecraft.red_sand", "EXCAVATING", 150));
        defaults.add(new BlockMapping("block.minecraft.gravel", "EXCAVATING", 150));
        defaults.add(new BlockMapping("block.minecraft.clay", "EXCAVATING", 250));
        defaults.add(new BlockMapping("block.minecraft.soul_sand", "EXCAVATING", 400));
        defaults.add(new BlockMapping("block.minecraft.soul_soil", "EXCAVATING", 400));

        // === MINING MAPPINGS (ORE OVERRIDES ONLY) ===

        // Mining: Overworld and Deepslate Ores (keeping original values)
        defaults.add(new BlockMapping("block.minecraft.coal_ore", "MINING", 250));           // 100 * 2.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_coal_ore", "MINING", 250));

        defaults.add(new BlockMapping("block.minecraft.copper_ore", "MINING", 250));         // 100 * 2.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_copper_ore", "MINING", 250));

        defaults.add(new BlockMapping("block.minecraft.iron_ore", "MINING", 350));           // 100 * 3.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_iron_ore", "MINING", 350));

        defaults.add(new BlockMapping("block.minecraft.redstone_ore", "MINING", 450));       // 100 * 4.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_redstone_ore", "MINING", 450));

        defaults.add(new BlockMapping("block.minecraft.gold_ore", "MINING", 550));           // 100 * 5.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_gold_ore", "MINING", 550));

        defaults.add(new BlockMapping("block.minecraft.lapis_ore", "MINING", 550));          // 100 * 5.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_lapis_ore", "MINING", 550));

        defaults.add(new BlockMapping("block.minecraft.emerald_ore", "MINING", 850));        // 100 * 8.5
        defaults.add(new BlockMapping("block.minecraft.deepslate_emerald_ore", "MINING", 850));

        defaults.add(new BlockMapping("block.minecraft.diamond_ore", "MINING", 1500));       // 100 * 15
        defaults.add(new BlockMapping("block.minecraft.deepslate_diamond_ore", "MINING", 1500));

        // SimpleSkills Rune ores
        defaults.add(new BlockMapping("block.simpleskills.rune_ore", "MINING", 900));
        defaults.add(new BlockMapping("block.simpleskills.deepslate_rune_ore", "MINING", 1100));

        // Mining: Nether Ores
        defaults.add(new BlockMapping("block.minecraft.nether_quartz_ore", "MINING", 150));  // 100 * 1.5
        defaults.add(new BlockMapping("block.minecraft.nether_gold_ore", "MINING", 150));    // More common than overworld gold

        // Convert to JSON
        for (BlockMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("block", mapping.block);
            entry.addProperty("skill", mapping.skill);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }

        json.add("block_mappings", mappings);
        return json;
    }

    /**
     * Loads smithing XP mappings from smithing_xp.json.
     */
    private static void loadSmithingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("smithing_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultSmithingXPConfig());
            var mappings = json.getAsJsonArray("smithing_mappings");
            SMITHING_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String action = mapping.get("action").getAsString();
                if (!mapping.has("xp") || !mapping.get("xp").isJsonPrimitive() || !mapping.get("xp").getAsJsonPrimitive().isNumber()) {
                    Simpleskills.LOGGER.warn("Invalid or missing 'xp' value for action {} in smithing_xp.json, skipping", action);
                    continue;
                }
                float xp = mapping.get("xp").getAsFloat();
                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Negative XP value {} for action {} in smithing_xp.json, skipping", xp, action);
                    continue;
                }
                SMITHING_XP_MAP.put(action, xp);
            }
            Simpleskills.LOGGER.info("Loaded {} smithing XP mappings.", SMITHING_XP_MAP.size());
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in smithing_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading smithing_xp.json: {}", e.getMessage());
        } catch (Exception e) {
            Simpleskills.LOGGER.error("Unexpected error loading smithing_xp.json: {}", e.getMessage());
        }
    }

    /**
     * Default smithing XP configuration.
     */
    private static JsonObject getDefaultSmithingXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record SmithingMapping(String action, float xp) {}
        SmithingMapping[] defaults = {
                new SmithingMapping("repair:minecraft:oak_planks", 50f),
                new SmithingMapping("repair:minecraft:spruce_planks", 50f),
                new SmithingMapping("repair:minecraft:birch_planks", 50f),
                new SmithingMapping("repair:minecraft:jungle_planks", 50f),
                new SmithingMapping("repair:minecraft:acacia_planks", 50f),
                new SmithingMapping("repair:minecraft:dark_oak_planks", 50f),
                new SmithingMapping("repair:minecraft:mangrove_planks", 50f),
                new SmithingMapping("repair:minecraft:cherry_planks", 50f),
                new SmithingMapping("repair:minecraft:bamboo_planks", 50f),
                new SmithingMapping("repair:minecraft:crimson_planks", 50f),
                new SmithingMapping("repair:minecraft:warped_planks", 50f),
                new SmithingMapping("repair:minecraft:pale_oak_planks", 50f),
                new SmithingMapping("repair:minecraft:cobblestone", 50f),
                new SmithingMapping("repair:minecraft:cobbled_deepslate", 50f),
                new SmithingMapping("repair:minecraft:blackstone", 50f),
                new SmithingMapping("repair:minecraft:leather", 50f),
                new SmithingMapping("repair:minecraft:copper_ingot", 50f),
                new SmithingMapping("repair:minecraft:gold_ingot", 50f),
                new SmithingMapping("repair:minecraft:turtle_scute", 50f),
                new SmithingMapping("repair:minecraft:iron_ingot", 50f),
                new SmithingMapping("repair:minecraft:phantom_membrane", 50f),
                new SmithingMapping("repair:minecraft:diamond", 50f),
                new SmithingMapping("repair:minecraft:netherite_ingot", 50f)
        };
        for (SmithingMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("action", mapping.action);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }
        json.add("smithing_mappings", mappings);
        return json;
    }

    /**
     * Default smithing multiplier configuration.
     */
    public static JsonObject getSmithingMultiplierConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record SmithingMultiplierMapping(String levelRange, float multiplier) {}
        SmithingMultiplierMapping[] defaults = {
                new SmithingMultiplierMapping("1-24", 1.00f),
                new SmithingMultiplierMapping("25-49", 1.050f),
                new SmithingMultiplierMapping("50-74", 1.075f),
                new SmithingMultiplierMapping("75-98", 1.10f),
                new SmithingMultiplierMapping("99-99", 1.20f)
        };
        for (SmithingMultiplierMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("level_range", mapping.levelRange);
            entry.addProperty("multiplier", mapping.multiplier);
            mappings.add(entry);
        }
        json.add("multiplier_mappings", mappings);
        return json;
    }

    /**
     * Loads smithing multiplier mappings from smithing_multipliers.json.
     */
    private static void loadSmithingMultiplierConfig() {
        Path filePath = CONFIG_DIR.resolve("smithing_multipliers.json");
        try {
            JsonObject json = loadJsonFile(filePath, getSmithingMultiplierConfig());
            var mappings = json.getAsJsonArray("multiplier_mappings");
            SMITHING_MULTIPLIER_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String levelRange = mapping.get("level_range").getAsString();
                float multiplier = mapping.get("multiplier").getAsFloat();
                if (multiplier < 0) {
                    Simpleskills.LOGGER.warn("Invalid multiplier value {} for level range {} in smithing_multipliers.json, skipping", multiplier, levelRange);
                    continue;
                }
                SMITHING_MULTIPLIER_MAP.put(levelRange, multiplier);
            }
            Simpleskills.LOGGER.info("Loaded smithing_multipliers.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in smithing_multipliers.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading smithing_multipliers.json: {}", e.getMessage());
        }
    }

    /**
     * Gets the smithing multiplier for a given level.
     */
    public static float getSmithingMultiplier(int level) {
        for (Map.Entry<String, Float> entry : SMITHING_MULTIPLIER_MAP.entrySet()) {
            String[] range = entry.getKey().split("-");
            int minLevel = Integer.parseInt(range[0]);
            int maxLevel = Integer.parseInt(range[1]);
            if (level >= minLevel && level <= maxLevel) {
                return entry.getValue();
            }
        }
        return 1.0f; // Default multiplier if no range matches
    }

    /**
     * Gets the XP for a smithing action.
     */
    public static float getSmithingXP(String action, Skills skill) {
        return SMITHING_XP_MAP.getOrDefault(action, (float) getBaseXP(skill));
    }

    public static Map<String, Float> getSmithingXPMap() {
        return SMITHING_XP_MAP;
    }

    /**
     * Default agility XP configuration.
     */
    private static JsonObject getDefaultAgilityXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record AgilityMapping(String action, int xp) {
        }
        AgilityMapping[] defaults = {
                new AgilityMapping("fall_damage", 60), // Base XP per heart of damage
                new AgilityMapping("jump", 20),
                new AgilityMapping("sprint", 20),
                new AgilityMapping("swim", 25),
                new AgilityMapping("sneak", 20)
        };
        for (AgilityMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("action", mapping.action);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }
        json.add("agility_mappings", mappings);
        return json;
    }

    /**
     * Loads alchemy multiplier mappings from alchemy_multipliers.json.
     */
    private static void loadAlchemyMultiplierConfig() {
        Path filePath = CONFIG_DIR.resolve("alchemy_multipliers.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultAlchemyMultiplierConfig());
            var mappings = json.getAsJsonArray("multiplier_mappings");
            ALCHEMY_MULTIPLIER_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String levelRange = mapping.get("level_range").getAsString();
                float multiplier = mapping.get("multiplier").getAsFloat();
                if (multiplier < 0) {
                    Simpleskills.LOGGER.warn("Invalid multiplier value {} for level range {} in alchemy_multipliers.json, skipping", multiplier, levelRange);
                    continue;
                }
                ALCHEMY_MULTIPLIER_MAP.put(levelRange, multiplier);
            }
            Simpleskills.LOGGER.info("Loaded alchemy_multipliers.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in alchemy_multipliers.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading alchemy_multipliers.json: {}", e.getMessage());
        }
    }

    /**
     * Default alchemy multiplier configuration.
     */
    private static JsonObject getDefaultAlchemyMultiplierConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record AlchemyMultiplierMapping(String levelRange, float multiplier) {}
        AlchemyMultiplierMapping[] defaults = {
                new AlchemyMultiplierMapping("1-24", 1.00f),
                new AlchemyMultiplierMapping("25-49", 1.25f),
                new AlchemyMultiplierMapping("50-74", 1.50f),
                new AlchemyMultiplierMapping("75-98", 1.75f),
                new AlchemyMultiplierMapping("99-99", 3.00f)
        };
        for (AlchemyMultiplierMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("level_range", mapping.levelRange);
            entry.addProperty("multiplier", mapping.multiplier);
            mappings.add(entry);
        }
        json.add("multiplier_mappings", mappings);
        return json;
    }

    /**
     * Gets the multiplier for an alchemy level.
     */
    public static float getAlchemyMultiplier(int level) {
        if (level >= 99) return ALCHEMY_MULTIPLIER_MAP.getOrDefault("99-99", 2.00f);
        else if (level >= 75) return ALCHEMY_MULTIPLIER_MAP.getOrDefault("75-98", 1.75f);
        else if (level >= 50) return ALCHEMY_MULTIPLIER_MAP.getOrDefault("50-74", 1.50f);
        else if (level >= 25) return ALCHEMY_MULTIPLIER_MAP.getOrDefault("25-49", 1.25f);
        else return ALCHEMY_MULTIPLIER_MAP.getOrDefault("1-24", 1.00f);
    }

    // Existing methods (unchanged, included for context)
    private static void loadAlchemyXPConfig() {
        Path filePath = CONFIG_DIR.resolve("alchemy_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultAlchemyXPConfig());
            var mappings = json.getAsJsonArray("alchemy_mappings");
            ALCHEMY_XP_MAP.clear();
            for (var element : mappings) {
                JsonObject mapping = element.getAsJsonObject();
                String potion = mapping.get("potion").getAsString();
                int xp = mapping.get("xp").getAsInt();
                if (xp < 0) {
                    Simpleskills.LOGGER.warn("Invalid XP value {} for potion {} in alchemy_xp.json, skipping", xp, potion);
                    continue;
                }
                ALCHEMY_XP_MAP.put(potion, xp);
            }
            Simpleskills.LOGGER.info("Loaded alchemy_xp.json");
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in alchemy_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading alchemy_xp.json: {}", e.getMessage());
        }
    }

    public static int getAlchemyXP(String potionTranslationKey, Skills skill) {
        return ALCHEMY_XP_MAP.getOrDefault(potionTranslationKey, getBaseXP(skill));
    }

    private static JsonObject getDefaultAlchemyXPConfig() {
        JsonObject json = new JsonObject();
        JsonArray mappings = new JsonArray();
        record AlchemyMapping(String potion, int xp) {}
        AlchemyMapping[] defaults = {
                new AlchemyMapping("potion.minecraft.turtle_master", 2500),
                new AlchemyMapping("potion.minecraft.long_turtle_master", 2600),
                new AlchemyMapping("potion.minecraft.strong_turtle_master", 2900),
                new AlchemyMapping("potion.minecraft.oozing", 2400),
                new AlchemyMapping("potion.minecraft.wind_charged", 2250),
                new AlchemyMapping("potion.minecraft.weaving", 2150),
                new AlchemyMapping("potion.minecraft.slow_falling", 2000),
                new AlchemyMapping("potion.minecraft.long_slow_falling", 2150),
                new AlchemyMapping("potion.minecraft.invisibility", 1850),
                new AlchemyMapping("potion.minecraft.long_invisibility", 2000),
                new AlchemyMapping("potion.minecraft.regeneration", 1750),
                new AlchemyMapping("potion.minecraft.long_regeneration", 1850),
                new AlchemyMapping("potion.minecraft.strong_regeneration", 2150),
                new AlchemyMapping("potion.minecraft.fire_resistance", 1600),
                new AlchemyMapping("potion.minecraft.long_fire_resistance", 1750),
                new AlchemyMapping("potion.minecraft.leaping", 1500),
                new AlchemyMapping("potion.minecraft.long_leaping", 1600),
                new AlchemyMapping("potion.minecraft.strong_leaping", 1900),
                new AlchemyMapping("potion.minecraft.night_vision", 1400),
                new AlchemyMapping("potion.minecraft.long_night_vision", 1500),
                new AlchemyMapping("potion.minecraft.slowness", 1250),
                new AlchemyMapping("potion.minecraft.long_slowness", 1400),
                new AlchemyMapping("potion.minecraft.strong_slowness", 1600),
                new AlchemyMapping("potion.minecraft.healing", 1150),
                new AlchemyMapping("potion.minecraft.strong_healing", 1500),
                new AlchemyMapping("potion.minecraft.harming", 1150),
                new AlchemyMapping("potion.minecraft.strong_harming", 1500),
                new AlchemyMapping("potion.minecraft.swiftness", 1150),
                new AlchemyMapping("potion.minecraft.long_swiftness", 1250),
                new AlchemyMapping("potion.minecraft.strong_swiftness", 1500),
                new AlchemyMapping("potion.minecraft.poison", 1150),
                new AlchemyMapping("potion.minecraft.long_poison", 1250),
                new AlchemyMapping("potion.minecraft.strong_poison", 1500),
                new AlchemyMapping("potion.minecraft.strength", 1150),
                new AlchemyMapping("potion.minecraft.long_strength", 1250),
                new AlchemyMapping("potion.minecraft.strong_strength", 1500),
                new AlchemyMapping("splash_potion.minecraft.turtle_master", 2750),
                new AlchemyMapping("splash_potion.minecraft.long_turtle_master", 2900),
                new AlchemyMapping("splash_potion.minecraft.strong_turtle_master", 3150),
                new AlchemyMapping("splash_potion.minecraft.oozing", 2600),
                new AlchemyMapping("splash_potion.minecraft.wind_charged", 2500),
                new AlchemyMapping("splash_potion.minecraft.weaving", 2400),
                new AlchemyMapping("splash_potion.minecraft.slow_falling", 2250),
                new AlchemyMapping("splash_potion.minecraft.long_slow_falling", 2400),
                new AlchemyMapping("splash_potion.minecraft.invisibility", 2150),
                new AlchemyMapping("splash_potion.minecraft.long_invisibility", 2250),
                new AlchemyMapping("splash_potion.minecraft.regeneration", 2000),
                new AlchemyMapping("splash_potion.minecraft.long_regeneration", 2150),
                new AlchemyMapping("splash_potion.minecraft.strong_regeneration", 2400),
                new AlchemyMapping("splash_potion.minecraft.fire_resistance", 1900),
                new AlchemyMapping("splash_potion.minecraft.long_fire_resistance", 2000),
                new AlchemyMapping("splash_potion.minecraft.leaping", 1750),
                new AlchemyMapping("splash_potion.minecraft.long_leaping", 1900),
                new AlchemyMapping("splash_potion.minecraft.strong_leaping", 2150),
                new AlchemyMapping("splash_potion.minecraft.night_vision", 1600),
                new AlchemyMapping("splash_potion.minecraft.long_night_vision", 1750),
                new AlchemyMapping("splash_potion.minecraft.slowness", 1500),
                new AlchemyMapping("splash_potion.minecraft.long_slowness", 1600),
                new AlchemyMapping("splash_potion.minecraft.strong_slowness", 1900),
                new AlchemyMapping("splash_potion.minecraft.healing", 1450),
                new AlchemyMapping("splash_potion.minecraft.strong_healing", 1750),
                new AlchemyMapping("splash_potion.minecraft.harming", 1450),
                new AlchemyMapping("splash_potion.minecraft.strong_harming", 1750),
                new AlchemyMapping("splash_potion.minecraft.swiftness", 1450),
                new AlchemyMapping("splash_potion.minecraft.long_swiftness", 1500),
                new AlchemyMapping("splash_potion.minecraft.strong_swiftness", 1750),
                new AlchemyMapping("splash_potion.minecraft.poison", 1450),
                new AlchemyMapping("splash_potion.minecraft.long_poison", 1500),
                new AlchemyMapping("splash_potion.minecraft.strong_poison", 1750),
                new AlchemyMapping("splash_potion.minecraft.strength", 1450),
                new AlchemyMapping("splash_potion.minecraft.long_strength", 1500),
                new AlchemyMapping("splash_potion.minecraft.strong_strength", 1750),
                new AlchemyMapping("lingering_potion.minecraft.turtle_master", 3150),
                new AlchemyMapping("lingering_potion.minecraft.long_turtle_master", 3250),
                new AlchemyMapping("lingering_potion.minecraft.strong_turtle_master", 3500),
                new AlchemyMapping("lingering_potion.minecraft.oozing", 3000),
                new AlchemyMapping("lingering_potion.minecraft.wind_charged", 2900),
                new AlchemyMapping("lingering_potion.minecraft.weaving", 2750),
                new AlchemyMapping("lingering_potion.minecraft.slow_falling", 2600),
                new AlchemyMapping("lingering_potion.minecraft.long_slow_falling", 2750),
                new AlchemyMapping("lingering_potion.minecraft.invisibility", 2500),
                new AlchemyMapping("lingering_potion.minecraft.long_invisibility", 2600),
                new AlchemyMapping("lingering_potion.minecraft.regeneration", 2400),
                new AlchemyMapping("lingering_potion.minecraft.long_regeneration", 2500),
                new AlchemyMapping("lingering_potion.minecraft.strong_regeneration", 2750),
                new AlchemyMapping("lingering_potion.minecraft.fire_resistance", 2250),
                new AlchemyMapping("lingering_potion.minecraft.long_fire_resistance", 2400),
                new AlchemyMapping("lingering_potion.minecraft.leaping", 2150),
                new AlchemyMapping("lingering_potion.minecraft.long_leaping", 2250),
                new AlchemyMapping("lingering_potion.minecraft.strong_leaping", 2500),
                new AlchemyMapping("lingering_potion.minecraft.night_vision", 2000),
                new AlchemyMapping("lingering_potion.minecraft.long_night_vision", 2150),
                new AlchemyMapping("lingering_potion.minecraft.slowness", 1900),
                new AlchemyMapping("lingering_potion.minecraft.long_slowness", 2000),
                new AlchemyMapping("lingering_potion.minecraft.strong_slowness", 2250),
                new AlchemyMapping("lingering_potion.minecraft.healing", 1750),
                new AlchemyMapping("lingering_potion.minecraft.strong_healing", 2150),
                new AlchemyMapping("lingering_potion.minecraft.harming", 1750),
                new AlchemyMapping("lingering_potion.minecraft.strong_harming", 2150),
                new AlchemyMapping("lingering_potion.minecraft.swiftness", 1750),
                new AlchemyMapping("lingering_potion.minecraft.long_swiftness", 1850),
                new AlchemyMapping("lingering_potion.minecraft.strong_swiftness", 2150),
                new AlchemyMapping("lingering_potion.minecraft.poison", 1750),
                new AlchemyMapping("lingering_potion.minecraft.long_poison", 1850),
                new AlchemyMapping("lingering_potion.minecraft.strong_poison", 2150),
                new AlchemyMapping("lingering_potion.minecraft.strength", 1750),
                new AlchemyMapping("lingering_potion.minecraft.long_strength", 1850),
                new AlchemyMapping("lingering_potion.minecraft.strong_strength", 2150)
        };
        for (AlchemyMapping mapping : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("potion", mapping.potion);
            entry.addProperty("xp", mapping.xp);
            mappings.add(entry);
        }
        json.add("alchemy_mappings", mappings);
        return json;
    }

/**
 * Default tool requirements configuration.
 */
private static JsonObject getDefaultToolRequirements() {
    JsonObject json = new JsonObject();
    record ToolRequirement(String id, String skill, int level) {
    }
    ToolRequirement[] defaults = {
            // Wooden Tools
            new ToolRequirement("minecraft:wooden_pickaxe", "MINING", 0),
            new ToolRequirement("minecraft:wooden_axe", "WOODCUTTING", 0),
            new ToolRequirement("minecraft:wooden_shovel", "EXCAVATING", 0),
            new ToolRequirement("minecraft:wooden_hoe", "FARMING", 0),

            // Golden Tools
            new ToolRequirement("minecraft:golden_pickaxe", "MINING", 5),
            new ToolRequirement("minecraft:golden_axe", "WOODCUTTING", 5),
            new ToolRequirement("minecraft:golden_shovel", "EXCAVATING", 5),
            new ToolRequirement("minecraft:golden_hoe", "FARMING", 5),

            // Stone Tools
            new ToolRequirement("minecraft:stone_pickaxe", "MINING", 10),
            new ToolRequirement("minecraft:stone_axe", "WOODCUTTING", 10),
            new ToolRequirement("minecraft:stone_shovel", "EXCAVATING", 10),
            new ToolRequirement("minecraft:stone_hoe", "FARMING", 10),

            // Copper Tools
            new ToolRequirement("minecraft:copper_pickaxe", "MINING", 15),
            new ToolRequirement("minecraft:copper_axe", "WOODCUTTING", 15),
            new ToolRequirement("minecraft:copper_shovel", "EXCAVATING", 15),
            new ToolRequirement("minecraft:copper_hoe", "FARMING", 15),

            // Iron Tools
            new ToolRequirement("minecraft:iron_pickaxe", "MINING", 25),
            new ToolRequirement("minecraft:iron_axe", "WOODCUTTING", 25),
            new ToolRequirement("minecraft:iron_shovel", "EXCAVATING", 25),
            new ToolRequirement("minecraft:iron_hoe", "FARMING", 25),

            // Diamond Tools
            new ToolRequirement("minecraft:diamond_pickaxe", "MINING", 30),
            new ToolRequirement("minecraft:diamond_axe", "WOODCUTTING", 30),
            new ToolRequirement("minecraft:diamond_shovel", "EXCAVATING", 30),
            new ToolRequirement("minecraft:diamond_hoe", "FARMING", 30),

            // Netherite Tools
            new ToolRequirement("minecraft:netherite_pickaxe", "MINING", 35),
            new ToolRequirement("minecraft:netherite_axe", "WOODCUTTING", 35),
            new ToolRequirement("minecraft:netherite_shovel", "EXCAVATING", 35),
            new ToolRequirement("minecraft:netherite_hoe", "FARMING", 35),

            // Shield
            new ToolRequirement("minecraft:shield", "DEFENSE", 5)
    };

        for (ToolRequirement req : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("skill", req.skill);
            entry.addProperty("level", req.level);
            entry.addProperty("prestige", 0);
            json.add(req.id, entry);
        }
        return json;
    }

/**
 * Default armor requirements configuration.
 */
private static JsonObject getDefaultArmorRequirements() {
    JsonObject json = new JsonObject();
    record ArmorRequirement(String id, String skill, int level) {
    }
    ArmorRequirement[] defaults = {
            // Leather (starter)
            new ArmorRequirement("minecraft:leather_helmet", "DEFENSE", 0),
            new ArmorRequirement("minecraft:leather_chestplate", "DEFENSE", 0),
            new ArmorRequirement("minecraft:leather_leggings", "DEFENSE", 0),
            new ArmorRequirement("minecraft:leather_boots", "DEFENSE", 0),

            // Gold
            new ArmorRequirement("minecraft:golden_helmet", "DEFENSE", 0),
            new ArmorRequirement("minecraft:golden_chestplate", "DEFENSE", 0),
            new ArmorRequirement("minecraft:golden_leggings", "DEFENSE", 0),
            new ArmorRequirement("minecraft:golden_boots", "DEFENSE", 0),

            // Copper
            new ArmorRequirement("minecraft:copper_helmet", "DEFENSE", 5),
            new ArmorRequirement("minecraft:copper_chestplate", "DEFENSE", 5),
            new ArmorRequirement("minecraft:copper_leggings", "DEFENSE", 5),
            new ArmorRequirement("minecraft:copper_boots", "DEFENSE", 5),

            // Turtle
            new ArmorRequirement("minecraft:turtle_helmet", "DEFENSE", 15),

            // Chainmail
            new ArmorRequirement("minecraft:chainmail_helmet", "DEFENSE", 15),
            new ArmorRequirement("minecraft:chainmail_chestplate", "DEFENSE", 15),
            new ArmorRequirement("minecraft:chainmail_leggings", "DEFENSE", 15),
            new ArmorRequirement("minecraft:chainmail_boots", "DEFENSE", 15),

            // Iron
            new ArmorRequirement("minecraft:iron_helmet", "DEFENSE", 20),
            new ArmorRequirement("minecraft:iron_chestplate", "DEFENSE", 20),
            new ArmorRequirement("minecraft:iron_leggings", "DEFENSE", 20),
            new ArmorRequirement("minecraft:iron_boots", "DEFENSE", 20),

            // Diamond
            new ArmorRequirement("minecraft:diamond_helmet", "DEFENSE", 25),
            new ArmorRequirement("minecraft:diamond_chestplate", "DEFENSE", 25),
            new ArmorRequirement("minecraft:diamond_leggings", "DEFENSE", 25),
            new ArmorRequirement("minecraft:diamond_boots", "DEFENSE", 25),

            // Netherite
            new ArmorRequirement("minecraft:netherite_helmet", "DEFENSE", 30),
            new ArmorRequirement("minecraft:netherite_chestplate", "DEFENSE", 30),
            new ArmorRequirement("minecraft:netherite_leggings", "DEFENSE", 30),
            new ArmorRequirement("minecraft:netherite_boots", "DEFENSE", 30),

            // Elytra
            new ArmorRequirement("minecraft:elytra", "PRAYER", 25)
    };
        for (ArmorRequirement req : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("skill", req.skill);
            entry.addProperty("level", req.level);
            entry.addProperty("prestige", 0);
            json.add(req.id, entry);
        }
        return json;
    }

    /**
     * Default weapon requirements configuration.
     */
    private static JsonObject getDefaultWeaponRequirements() {
        JsonObject json = new JsonObject();
        record WeaponRequirement(String id, String skill, int level) {
        }
        WeaponRequirement[] defaults = {
                // Wooden Weapons
                new WeaponRequirement("minecraft:wooden_sword", "SLAYING", 0),
                new WeaponRequirement("minecraft:wooden_axe", "SLAYING", 0),
                new WeaponRequirement("minecraft:wooden_spear", "SLAYING", 0),

                // Golden Weapons
                new WeaponRequirement("minecraft:golden_sword", "SLAYING", 5),
                new WeaponRequirement("minecraft:golden_axe", "SLAYING", 5),
                new WeaponRequirement("minecraft:golden_spear", "SLAYING", 5),

                // Stone Weapons
                new WeaponRequirement("minecraft:stone_sword", "SLAYING", 10),
                new WeaponRequirement("minecraft:stone_axe", "SLAYING", 10),
                new WeaponRequirement("minecraft:stone_spear", "SLAYING", 10),

                // Copper Weapons
                new WeaponRequirement("minecraft:copper_sword", "SLAYING", 15),
                new WeaponRequirement("minecraft:copper_axe", "SLAYING", 15),
                new WeaponRequirement("minecraft:copper_spear", "SLAYING", 15),

                // Iron Weapons
                new WeaponRequirement("minecraft:iron_sword", "SLAYING", 20),
                new WeaponRequirement("minecraft:iron_axe", "SLAYING", 20),
                new WeaponRequirement("minecraft:iron_spear", "SLAYING", 20),

                // Diamond Weapons
                new WeaponRequirement("minecraft:diamond_sword", "SLAYING", 25),
                new WeaponRequirement("minecraft:diamond_axe", "SLAYING", 25),
                new WeaponRequirement("minecraft:diamond_spear", "SLAYING", 25),

                // Netherite Weapons
                new WeaponRequirement("minecraft:netherite_sword", "SLAYING", 35),
                new WeaponRequirement("minecraft:netherite_axe", "SLAYING", 35),
                new WeaponRequirement("minecraft:netherite_spear", "SLAYING", 35),

                // Unique / Misc Weapons
                new WeaponRequirement("minecraft:mace", "SLAYING", 35),

                // Ranged Weapons (grouped separately)
                new WeaponRequirement("minecraft:bow", "RANGED", 0),
                new WeaponRequirement("minecraft:crossbow", "RANGED", 10),
                new WeaponRequirement("minecraft:trident", "RANGED", 30)
        };

        for (WeaponRequirement req : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("skill", req.skill);
            entry.addProperty("level", req.level);
            entry.addProperty("prestige", 0);
            json.add(req.id, entry);
        }
        return json;
    }

    /**
     * Loads farming XP mappings from farming_xp.json with enhanced crop configuration.
     */
    private static void loadFarmingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("farming_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultFarmingXPConfig());
            FARMING_ACTION_XP_MAP.clear();
            CROP_CONFIGS.clear();

            if (json.has("actions") && json.get("actions").isJsonObject()) {
                JsonObject actions = json.getAsJsonObject("actions");
                for (Map.Entry<String, JsonElement> entry : actions.entrySet()) {
                    int xp = entry.getValue().getAsInt();
                    if (xp >= 0) {
                        FARMING_ACTION_XP_MAP.put(entry.getKey(), xp);
                    }
                }
            }

            if (json.has("blocks") && json.get("blocks").isJsonArray()) {
                for (JsonElement element : json.getAsJsonArray("blocks")) {
                    JsonObject mapping = element.getAsJsonObject();
                    String block = mapping.get("block").getAsString();
                    int xp = mapping.get("xp").getAsInt();

                    // New fields for crop configuration
                    String ageProperty = mapping.has("age_property") ? mapping.get("age_property").getAsString() : "NONE";
                    int maturityAge = mapping.has("maturity_age") ? mapping.get("maturity_age").getAsInt() : -1;

                    if (xp >= 0) {
                        CROP_CONFIGS.put(block, new CropConfig(block, ageProperty, maturityAge, xp));
                    }
                }
            }
            Simpleskills.LOGGER.info("Loaded farming_xp.json with {} crop configurations", CROP_CONFIGS.size());
        } catch (JsonSyntaxException e) {
            Simpleskills.LOGGER.error("JSON syntax error in farming_xp.json: {}", e.getMessage());
        } catch (IOException e) {
            Simpleskills.LOGGER.error("Error loading farming_xp.json: {}", e.getMessage());
        }
    }

    /**
     * Represents a crop configuration with age property and maturity threshold.
     */
    public record CropConfig(
            String block,
            String ageProperty, // "AGE_7", "AGE_3", "AGE_2", or "NONE"
            int maturityAge,
            int xp
    ) {}

    /**
     * Default farming XP configuration with age properties.
     */
    private static JsonObject getDefaultFarmingXPConfig() {
        JsonObject json = new JsonObject();
        JsonObject actions = new JsonObject();
        actions.addProperty("animal_feed_breed", 250);
        actions.addProperty("animal_feed_grow", 25);
        actions.addProperty("shear_sheep", 150);
        json.add("actions", actions);

        JsonArray blocks = new JsonArray();
        record FarmingBlock(String block, int xp, String ageProperty, int maturityAge) {}
        FarmingBlock[] defaults = new FarmingBlock[] {
                new FarmingBlock("block.minecraft.wheat", 275, "AGE_7", 7),
                new FarmingBlock("block.minecraft.carrots", 275, "AGE_7", 7),
                new FarmingBlock("block.minecraft.potatoes", 300, "AGE_7", 7),
                new FarmingBlock("block.minecraft.beetroots", 250, "AGE_3", 3),
                new FarmingBlock("block.minecraft.melon", 100, "NONE", -1),
                new FarmingBlock("block.minecraft.nether_wart", 350, "AGE_3", 3),
                new FarmingBlock("block.minecraft.cocoa", 250, "AGE_2", 2)
        };
        for (FarmingBlock fb : defaults) {
            JsonObject entry = new JsonObject();
            entry.addProperty("block", fb.block());
            entry.addProperty("xp", fb.xp());
            entry.addProperty("age_property", fb.ageProperty());
            entry.addProperty("maturity_age", fb.maturityAge());
            blocks.add(entry);
        }
        json.add("blocks", blocks);
        return json;
    }

    /**
     * Gets the crop configuration for a block translation key.
     */
    public static CropConfig getCropConfig(String blockTranslationKey) {
        return CROP_CONFIGS.get(blockTranslationKey);
    }

    /**
     * Checks if a block is configured as a crop.
     */
    public static boolean isCropBlock(String blockTranslationKey) {
        return CROP_CONFIGS.containsKey(blockTranslationKey);
    }

    /**
     * Checks if the custom (rank based) fishing loot tables are enabled.
     */
    public static boolean isCustomFishingLootEnabled() {
        try {
            if (featureConfig.has("custom_fishing_loot_enabled")) {
                return featureConfig.get("custom_fishing_loot_enabled").getAsBoolean();
            }
        } catch (Exception e) {
            Simpleskills.LOGGER.warn("Error reading custom_fishing_loot_enabled; defaulting to true");
        }
        return true;
    }

    /**
     * Checks if the fishing speed bonus is enabled.
     */
    public static boolean isFishingSpeedBonusEnabled() {
        try {
            if (featureConfig.has("fishing_speed_bonus_enabled")) {
                return featureConfig.get("fishing_speed_bonus_enabled").getAsBoolean();
            } else if (featureConfig.has("features")) {
                JsonObject features = featureConfig.getAsJsonObject("features");
                if (features != null && features.has("fishing_speed_bonus_enabled")) {
                    return features.get("fishing_speed_bonus_enabled").getAsBoolean();
                }
            }
            return true; // Default from getDefaultFeatureConfig()
        } catch (Exception e) {
            Simpleskills.LOGGER.warn("Error reading fishing_speed_bonus_enabled; defaulting to true");
            return true;
        }
    }

    /**
     * Loads fishing XP mappings from fishing_xp.json.
     */
    private static void loadFishingXPConfig() {
        Path filePath = CONFIG_DIR.resolve("fishing_xp.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultFishingXPConfig());
            for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
                String action = entry.getKey();
                int xp = entry.getValue().getAsInt();
                if (xp >= 0) {
                    FISHING_XP_MAP.put(action, xp);
                }
            }
        } catch (Exception e) {
            Simpleskills.LOGGER.warn("Error loading fishing_xp.json: {}", e.getMessage());
        }
    }

    private static JsonObject getDefaultFishingXPConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("catch", 1250);
        return json;
    }

    private static void loadFishingLootConfig() {
        Path filePath = CONFIG_DIR.resolve("fishing_loot.json");
        try {
            JsonObject json = loadJsonFile(filePath, getDefaultFishingLootConfig());
            for (Map.Entry<String, JsonElement> entry : json.entrySet()) {
                String range = entry.getKey();
                String lootTableStr = entry.getValue().getAsString();
                try {
                    Identifier id = Identifier.parse(lootTableStr);
                    FISHING_LOOT_TABLES.put(range, id);
                } catch (Exception e) {
                    Simpleskills.LOGGER.warn("Invalid loot table ID {} for range {} in fishing_loot.json", lootTableStr, range);
                }
            }
        } catch (Exception e) {
            Simpleskills.LOGGER.warn("Error loading fishing_loot.json: {}", e.getMessage());
        }
    }

    private static JsonObject getDefaultFishingLootConfig() {
        JsonObject json = new JsonObject();
        json.addProperty("1-24", "simpleskills:fishing/simpleskills_fishing_novice");
        json.addProperty("25-49", "simpleskills:fishing/simpleskills_fishing_journeyman");
        json.addProperty("50-74", "simpleskills:fishing/simpleskills_fishing_artisan");
        json.addProperty("75-98", "simpleskills:fishing/simpleskills_fishing_expert");
        json.addProperty("99-99", "simpleskills:fishing/simpleskills_fishing_grandmaster");
        return json;
    }

    /**
     * Default enchantment requirements configuration.
     */
    private static JsonObject getDefaultEnchantmentRequirements() {
        JsonObject json = new JsonObject();
        json.addProperty("enchantment_xp_per_level_squared", 100);

        JsonObject requirements = new JsonObject();

        // Efficiency
        JsonArray efficiencyReqs = new JsonArray();
        JsonObject eff1 = new JsonObject();
        eff1.addProperty("enchantmentLevel", 4);
        eff1.addProperty("skill", "ENCHANTING");
        eff1.addProperty("level", 15);
        efficiencyReqs.add(eff1);

        JsonObject eff5 = new JsonObject();
        eff5.addProperty("enchantmentLevel", 5);
        eff5.addProperty("skill", "ENCHANTING");
        eff5.addProperty("level", 75);
        efficiencyReqs.add(eff5);
        requirements.add("minecraft:efficiency", efficiencyReqs);

        // Fortune
        JsonArray fortuneReqs = new JsonArray();
        JsonObject fort3 = new JsonObject();
        fort3.addProperty("enchantmentLevel", 3);
        fort3.addProperty("skill", "ENCHANTING");
        fort3.addProperty("level", 25);
        fortuneReqs.add(fort3);
        requirements.add("minecraft:fortune", fortuneReqs);

        // Sharpness
        JsonArray sharpReqs = new JsonArray();
        JsonObject sharp5 = new JsonObject();
        sharp5.addProperty("enchantmentLevel", 5);
        sharp5.addProperty("skill", "ENCHANTING");
        sharp5.addProperty("level", 50);
        sharpReqs.add(sharp5);
        requirements.add("minecraft:sharpness", sharpReqs);

        // Power
        JsonArray powerReqs = new JsonArray();
        JsonObject pow5 = new JsonObject();
        pow5.addProperty("enchantmentLevel", 5);
        pow5.addProperty("skill", "ENCHANTING");
        pow5.addProperty("level", 50);
        powerReqs.add(pow5);
        requirements.add("minecraft:power", powerReqs);

        // Mending
        JsonArray mendingReqs = new JsonArray();
        JsonObject mend1 = new JsonObject();
        mend1.addProperty("enchantmentLevel", 1);
        mend1.addProperty("skill", "ENCHANTING");
        mend1.addProperty("level", 99);
        mendingReqs.add(mend1);
        requirements.add("minecraft:mending", mendingReqs);

        json.add("requirements", requirements);
        return json;
    }

    public static int getFarmingActionXP(String actionKey, Skills skill) {
        return FARMING_ACTION_XP_MAP.getOrDefault(actionKey, getBaseXP(skill));

    }


    /**
     * Gets the base XP for a skill.
     */
    public static int getBaseXP(Skills skill) {
        return BASE_XP_MAP.getOrDefault(skill, 100);
    }

    /**
     * Gets the skill associated with a block.
     */
    public static Skills getBlockSkill(String blockTranslationKey) {
        return BLOCK_SKILL_MAP.get(blockTranslationKey);
    }

    /**
     * Gets the XP for breaking a block.
     */
    public static int getBlockXP(String blockTranslationKey, Skills skill) {
        return BLOCK_XP_MAP.getOrDefault(blockTranslationKey, getBaseXP(skill));
    }

    /**
     * Returns the configured XP override for a specific block if present,
     * otherwise null. Useful for allowing dynamic defaults (e.g., hardness-based)
     * with explicit per-block overrides via block_mappings.json.
     */
    public static Integer getBlockXPOverride(String blockTranslationKey) {
        return BLOCK_XP_MAP.containsKey(blockTranslationKey) ? BLOCK_XP_MAP.get(blockTranslationKey) : null;
    }

    /**
     * Gets the requirement for a tool.
     */
    public static SkillRequirement getToolRequirement(String id) {
        return TOOL_REQUIREMENTS.get(id);
    }

    /**
     * Gets the requirement for an armor piece.
     */
    public static SkillRequirement getArmorRequirement(String id) {
        return ARMOR_REQUIREMENTS.get(id);
    }

    /**
     * Gets the requirement for a weapon.
     */
    public static SkillRequirement getWeaponRequirement(String id) {
        return WEAPON_REQUIREMENTS.get(id);
    }

    /**
     * Gets the requirement for an enchantment at a specific level.
     * Returns the requirement that matches the exact enchantment level, or null if none exists.
     */
    public static SkillRequirement getEnchantmentRequirement(String enchantmentId, int enchantmentLevel) {
        List<SkillRequirement> requirements = ENCHANTMENT_REQUIREMENTS.get(enchantmentId);
        if (requirements == null || requirements.isEmpty()) {
            return null;
        }

        // Look for an exact match first
        for (SkillRequirement req : requirements) {
            if (req.getEnchantmentLevel() != null && req.getEnchantmentLevel() == enchantmentLevel) {
                return req;
            }
        }

        // No exact match found - no requirement for this level
        return null;
    }

    /**
     * Add getter for XP multiplier:
     */
    public static int getEnchantmentXpPerLevelSquared() {
        return enchantmentXpPerLevelSquared;
    }

    /**
     * Gets the XP for an agility action.
     */
    public static int getAgilityXP(String action, Skills skill) {
        return AGILITY_XP_MAP.getOrDefault(action, getBaseXP(skill));
    }

    /**
     * Gets the XP for a fishing action.
     */
    public static int getFishingXP(String action, Skills skill) {
        return FISHING_XP_MAP.getOrDefault(action, getBaseXP(skill));
    }

    /**
     * Gets the fishing loot table for a given skill level.
     */
    public static Identifier getFishingLootTable(int fishingLevel) {
        if (fishingLevel >= 99) {
            return FISHING_LOOT_TABLES.getOrDefault("99-99", Identifier.fromNamespaceAndPath("simpleskills", "fishing/simpleskills_fishing_grandmaster"));
        } else if (fishingLevel >= 75) {
            return FISHING_LOOT_TABLES.getOrDefault("75-98", Identifier.fromNamespaceAndPath("simpleskills", "fishing/simpleskills_fishing_expert"));
        } else if (fishingLevel >= 50) {
            return FISHING_LOOT_TABLES.getOrDefault("50-74", Identifier.fromNamespaceAndPath("simpleskills", "fishing/simpleskills_fishing_artisan"));
        } else if (fishingLevel >= 25) {
            return FISHING_LOOT_TABLES.getOrDefault("25-49", Identifier.fromNamespaceAndPath("simpleskills", "fishing/simpleskills_fishing_journeyman"));
        } else {
            return FISHING_LOOT_TABLES.getOrDefault("1-24", Identifier.fromNamespaceAndPath("simpleskills", "fishing/simpleskills_fishing_novice"));
        }
    }

    /**
     * Gets the feature configuration.
     */
    public static JsonObject getFeatureConfig() {
        return featureConfig;
    }

    public static JsonObject getAgilityConfig() {
        if (featureConfig != null && featureConfig.has("agility") && featureConfig.get("agility").isJsonObject()) {
            return featureConfig.getAsJsonObject("agility");
        }
        JsonObject defaults = new JsonObject();
        defaults.addProperty("dash_unlocked_at", 15);
        defaults.addProperty("dash_cooldown_ticks_base", 100);
        defaults.addProperty("dash_cooldown_reduction_per_level", 0.5);
        defaults.addProperty("dash_impulse", 1.2);
        defaults.addProperty("dash_vertical_impulse", 0.35);
        defaults.addProperty("dash_iframe_ticks", 4);
        defaults.addProperty("dash_exhaustion", 1.0);
        defaults.addProperty("double_jump_unlocked_at", 10);
        defaults.addProperty("double_jump_vertical_velocity", 0.9);
        defaults.addProperty("double_jump_exhaustion", 1.0);
        return defaults;
    }
}
